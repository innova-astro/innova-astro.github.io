


#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaIntegrator : InNova Astro Photo Suite > InNova Integrator
#feature-icon  InNovaIcon.svg
#feature-info  Integration and astrophotography processing for InNova Astro Photo Suite. \
<br/>\
Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#define TITLE "InNova Integrator"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>
#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "InNovaIntegratorImageSolver"
#include "lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "InNova Integrator"

var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process11.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"
#include "lib/process01.js"
#include "lib/process12.js"


var ProjecTname = "🔭 InNova Integrator";


var ProjecTver  = "v.1.0.build.0349";


var _0xd5ac9036f9 = false;
var InNovaAdaptiveStretchBuild = "0066";
var _0x62abc0e7dd = String.fromCharCode(51,49,97,100,48,56,120,106,114);
var _0x24a79c05f1 = String.fromCharCode(53,52,48,48,54,54,98,101,97,97,50,97,49,56,100,98,51,100,55,101,99,97,55,54,55,99,49,55,52,50,52,52,50,57,49,97,53,100,100,53,48,55,99,53,98,50,55,99,50,55,101,56,100,101,97,48,50,57,102,56,102,50,51,52);
var CanStartApp = MiraRequireCompatiblePixInsight("InNova Integrator");
var ProjecTypevar = "SHO";
var ProjecTypevar2 = "0";
var ProjecTypevarRec = "SHO";
var InNovaProjectSelectionLoggingEnabled = false;
var AlignmenTypevar = "Ha";
var OptionLinkRGB = "false";
var PimageSii = "EMPTY";
var PimageHa = "EMPTY";
var PimageOiii = "EMPTY";
var PimageRed = "EMPTY";
var PimageGreen = "EMPTY";
var PimageBlue = "EMPTY";
var PimageLuminance = "EMPTY";
var PimageOsc = "EMPTY";
var Option1var = "OFF";
var OptionHavar = "OFF";
var VarProcesStar = "OFF";
var Option2var2 = "OFF";
var Option300 = "OFF"
var OptionGraXNoise = "OFF";


var OptionNarrowbandToRGB = "OFF";
var OptionOpenInNovaEditor = "ON";
var InNovaEditorPendingLaunch = false;
var InNovaEditorPendingSourceId = "";
var InNovaEditorPendingProjectType = "RGB";
var InNovaRunActive = false;
var InNovaStopRequested = false;
var InNovaStopCleanupRequested = false;

function InNovaRequestStop(origin)
{
   if (!InNovaRunActive)
      return false;

   InNovaStopRequested = true;
   InNovaStopCleanupRequested = true;
   InNovaEditorPendingLaunch = false;
   console.show();
   console.warningln(
      "\n⛔ STOP requested" +
      (origin && origin.length > 0 ? " from " + origin : "") +
      ". InNova will stop at the nearest safe checkpoint and clean the project.");

   if (typeof dialog !== "undefined" && dialog) {
      dialog.workingLabel.foregroundColor = 0xd71920;
      dialog.workingStatusText =
         "⛔ Stopping safely. Cleaning the project next...";
      dialog.elapsedStartTime = Date.now();
      dialog.refreshWorkingLabel();
      dialog.exitButton.text = "Stopping...";
      dialog.exitButton.enabled = false;
      dialog.exitButton.update();
   }
   CoreApplication.processEvents();
   return true;
}

function InNovaAbortCheckpoint()
{
   CoreApplication.processEvents();
   if (!InNovaStopRequested)
      return;

   let stopError = new Error("InNova project stopped by the user.");
   stopError.inNovaUserStop = true;
   throw stopError;
}
var OptionDarkStructureEnhance = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var OptionNoiseXterminator  = "OFF";
var OptionMLDenoise = "OFF";
var OptionStarXterminator = "OFF";
var OptionBlurXterminator = "OFF";
var OptionHighpass = "OFF";
var OptionGradient ="ON";
var OptionImageSolver = "OFF";


var OptionObjectType = "STARS";
var OptionDBE = "OFF";
var OptionVarStars = "OFF";
var OptionMgc ="OFF";
var OptionVaonisVespera = "OFF";


var OptionSeestar = "OFF";
var OptionFast = "OFF";
var VarPGlobal = "EMPTY";
var _0x7fbd7dc1d0 ="EMPTY";
var NewGreenValue = 0.0;
var NewMagentaValue = 1;
var NewStarsValue = 1;
var isStarProcess = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";
var OptionHSOvar = "OFF";
var OptionSharpenNonstellar = 0.20;


function MiraRequirePipelineWindow(windowId, stageName)
{
   let window = ImageWindow.windowById(windowId);
   if (window && !window.isNull && window.mainView &&
       !window.mainView.isNull)
      return true;

   console.criticalln(
      "❌ " + stageName + " did not create the required window: " +
      windowId + ". Processing has been stopped safely.");
   return false;
}

function MiraValidateFinalWindowContract(requireStars, stageName)
{
   if (!MiraRequirePipelineWindow("Final_starless", stageName))
      return false;

   if (requireStars) {
      if (!MiraRequirePipelineWindow("Final_stars", stageName))
         return false;
      if (!MiraRequirePipelineWindow("Final_Result", stageName))
         return false;
   }

   return true;
}


var InteractiveProcessStrengths = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var InteractiveProcessMaskModes = {
   DeepSNR: "none",
   MLDenoise: "none",
   NoiseXTerminator: "none",
   BlurXTerminator: "none",
   HighPass: "none",
   NarrowbandToRGB: "none"
};
var InteractiveProcessMaskBanks = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};


var InNovaEditorTitle = "🪐 InNova Editor";

function InNovaIntegratorResetInNovaEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaIntegratorCloneForInNovaEditor(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      image.isColor,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      output.keywords = sourceWindow.keywords;
   }
   catch (e) {
   }

   return output;
}

function InNovaIntegratorOpenInNovaEditor(sourceId, projectType)
{
   InNovaEditorPendingLaunch = false;

   let source = ImageWindow.windowById(sourceId);
   if (!source || source.isNull || !source.mainView ||
       source.mainView.isNull || !source.mainView.image ||
       source.mainView.image.numberOfChannels < 3) {
      console.show();
      console.warningln(
         "⚠️ 🪐 InNova Editor was not opened because the final color image is no longer available.");
      return false;
   }

   let editorProjectType =
      projectType === "SHO" || projectType === "HOO" ||
      projectType === "LRGB" || projectType === "OSC" ?
      projectType : "RGB";
   let outputId = MiraUniqueWindowId(sourceId + "_InNovaEditor");
   let output = null;

   try {
      output = InNovaIntegratorCloneForInNovaEditor(source, outputId);
      InNovaIntegratorResetInNovaEditorState();
      ProjecTypevar = editorProjectType;
      ProjecTypevarRec = editorProjectType;

      console.noteln("\n🪐 Opening InNova Editor: " + sourceId);
      console.writeln("🔭 Project type received from InNova Integrator: " +
                      editorProjectType);

      let editorLaunchContext = {
         source: "InNova Integrator",
         requestedModule: ""
      };
      let detectedStarPair =
         typeof InNovaEditorFindStandaloneStarPair === "function" ?
         InNovaEditorFindStandaloneStarPair(output) : null;

      if (detectedStarPair) {
         editorLaunchContext.starlessId = detectedStarPair.starlessId;
         editorLaunchContext.starsId = detectedStarPair.starsId;
         console.noteln("\n🌟 InNova Star Refinement layers linked:");
         console.writeln("   Starless: " + detectedStarPair.starlessId);
         console.writeln("   Stars: " + detectedStarPair.starsId);
      }

      let editorResult = InNovaEditorRunProEditor(
         output.mainView,
         editorProjectType,
         editorLaunchContext);
      if (!editorResult.accepted && editorResult.openRequested) {
         output.forceClose();
         output = null;
         let requestedId = InNovaEditorChooseOpenColorImage();
         if (requestedId.length === 0)
            return false;
         let upperId = requestedId.toUpperCase();
         let requestedType =
            upperId.indexOf("SHO") !== -1 ? "SHO" :
            upperId.indexOf("HOO") !== -1 ? "HOO" :
            upperId.indexOf("LRGB") !== -1 ? "LRGB" :
            upperId.indexOf("OSC") !== -1 ||
            upperId.indexOf("VAONIS") !== -1 ||
            upperId.indexOf("SEESTAR") !== -1 ? "OSC" : "RGB";
         return InNovaIntegratorOpenInNovaEditor(
            requestedId, requestedType);
      }
      if (!editorResult.accepted && editorResult.cancelled) {
         output.forceClose();
         output = null;
         console.noteln("🪐 InNova Editor editing cancelled.");
         return false;
      }
      if (!editorResult.accepted)
         throw new Error(
            "The image editor could not prepare the final image.");

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Editor result created: " + outputId);
      return true;
   }
   catch (error) {
      if (output && !output.isNull)
         output.forceClose();

      console.show();
      console.criticalln("❌ 🪐 InNova Editor could not be opened: " +
                         (error.message || error));
      new MessageBox(
         "InNova Editor could not open the final image.\n\n" +
         "Review the Process Console for details.",
         "InNova Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }
}
var _0x2ec0322bf9 = "";
var OptionMergePro1  = "<Select an Image>";
var OptionshowConsolRadio = "ON";
var OptionRemaind2 = null;
var OptionSTFvar = "OFF";
var OptionEnabledPreview2 ="OFF";
var OptionGreen = "OFF";
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
var defaultProjectPath = _0x20432becd9() + "/";
var originalFilePathMars1 = defaultProjectPath;
var originalFilePathMars2 = defaultProjectPath;
var originalFilePathMarsfin1 = defaultProjectPath;
var originalFilePathMarsfin2 = defaultProjectPath;
var originalFilePathMLDenoise = defaultProjectPath;
var originalFilePathMLDenoisefin = defaultProjectPath;
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MLDenoiseFound ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMarsFirst ="MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond ="MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel ="MLDenoise_v5.xmlm";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;


console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");
if (CanStartApp)
   _0x2fd93a6a67();
console.writeln("");
console.noteln("Checking third-party software:");

defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";


let savedMgcSensorName = Settings.read("MgcSensorName", DataType_String);
if (typeof savedMgcSensorName === "string" &&
    savedMgcSensorName.trim().length > 0)
   SensorName = savedMgcSensorName;

let savedMgcNarrowband = Settings.read("MgcNarrowband", DataType_String);
if (savedMgcNarrowband === "ON" || savedMgcNarrowband === "OFF")
   Narrowband = savedMgcNarrowband;

function MiraRestorePositiveMgcNumber(key, fallback)
{
   let savedValue = Settings.read(key, DataType_Double);
   return typeof savedValue === "number" && isFinite(savedValue) &&
          savedValue > 0 ? savedValue : fallback;
}

defaultGrayWavelength = MiraRestorePositiveMgcNumber(
   "MgcGrayWavelength", defaultGrayWavelength);
defaultGrayBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGrayBandwidth", defaultGrayBandwidth);
defaultRedWavelength = MiraRestorePositiveMgcNumber(
   "MgcRedWavelength", defaultRedWavelength);
defaultRedBandwidth = MiraRestorePositiveMgcNumber(
   "MgcRedBandwidth", defaultRedBandwidth);
defaultGreenWavelength = MiraRestorePositiveMgcNumber(
   "MgcGreenWavelength", defaultGreenWavelength);
defaultGreenBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGreenBandwidth", defaultGreenBandwidth);
defaultBlueWavelength = MiraRestorePositiveMgcNumber(
   "MgcBlueWavelength", defaultBlueWavelength);
defaultBlueBandwidth = MiraRestorePositiveMgcNumber(
   "MgcBlueBandwidth", defaultBlueBandwidth);

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}


getFilePath(originalFilePathMars1, originalFilePathMars2);

if (CanStartApp && !RuntimeReady())
{
   CanStartApp = false;

   console.criticalln("Initialization cancelled.");

   new MessageBox(
      "Unable to initialize processing engine.",
      "InNova Integrator",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
}
else if (CanStartApp)
{
   CanStartApp = true;
}

const _0xcaa4b45002 =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiIwZThlNmI2My1hZTk1LTQ1MjctOWNjMS1iN2JlMzc2N2ViZmYiLCJjaGVja291dEZsb3dJZCI6ImVlNjNjNTliLWI1OTQtNGY3MS1iMTFiLWJmZjlmNDA2MTIzNyIsImlzVjMiOnRydWV9";

const _0xb503268579 =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiJiNDE5M2JlNi00NTg0LTRjYmMtOWEyOS1iYjE0YjJjYzRlM2IiLCJjaGVja291dEZsb3dJZCI6ImY4YTMyNmVjLTI4MDQtNGIzNi1iN2UxLTlmZTMyYTlmNGY0NiIsImlzVjMiOnRydWV9";

class _0x20b86eba4d extends Dialog
{
   constructor()
   {
      super();

      let self = this;
      this.selectedUrl = "";
      this.recoverExisting = false;
      this.supportRecovery = false;
      let paidRecoveryAvailable = _0x13cd1b694d();
      this.windowTitle = String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110,32,80,108,97,110,115);

      let titleLabel = new Label(this);
      titleLabel.useRichText = true;
      titleLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      titleLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,67,104,111,111,115,101,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,60,47,112,62) +
         "<p align=\"center\">Select the billing period that suits you.</p>";


      titleLabel.onMousePress = function ()
      {
         if (paidRecoveryAvailable)
            return;
         paidRecoveryAvailable = true;
         transferGroup.visible = true;
         supportGroup.visible = true;
         self.adjustToContents();
         self.setFixedSize();
      };

      let monthlyGroup = new GroupBox(this);
      monthlyGroup.title = "Monthly";
      monthlyGroup.setFixedWidth(260);
      monthlyGroup.sizer = new VerticalSizer;
      monthlyGroup.sizer.margin = 12;
      monthlyGroup.sizer.spacing = 10;

      let monthlyPriceLabel = new Label(monthlyGroup);
      monthlyPriceLabel.useRichText = true;
      monthlyPriceLabel.wordWrapping = true;
      monthlyPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      monthlyPriceLabel.text =
         "<p align=\"center\"><b>&euro;6.99 / month</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Billed every month until cancelled.</p>";

      let monthlyButton = new PushButton(monthlyGroup);
      monthlyButton.text = "Choose Monthly";
      monthlyButton.setFixedHeight(34);
      monthlyButton.onClick = function ()
      {
         self.selectedUrl = _0xcaa4b45002;
         self.ok();
      };

      monthlyGroup.sizer.add(monthlyPriceLabel);
      monthlyGroup.sizer.addStretch();
      monthlyGroup.sizer.add(monthlyButton);

      let annualGroup = new GroupBox(this);
      annualGroup.title = "Annual";
      annualGroup.setFixedWidth(260);
      annualGroup.sizer = new VerticalSizer;
      annualGroup.sizer.margin = 12;
      annualGroup.sizer.spacing = 10;

      let annualPriceLabel = new Label(annualGroup);
      annualPriceLabel.useRichText = true;
      annualPriceLabel.wordWrapping = true;
      annualPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      annualPriceLabel.text =
         "<p align=\"center\"><b>&euro;69.99 / year</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Save &euro;13.89 compared with<br>12 monthly payments.</p>";

      let annualButton = new PushButton(annualGroup);
      annualButton.text = "Choose Annual - Best Value";
      annualButton.icon = this.scaledResource( ":/icons/ok.png" );
      annualButton.toolTip =
         "Recommended: save EUR 13.89 compared with 12 monthly payments.";
      annualButton.setFixedHeight(34);
      annualButton.onClick = function ()
      {
         self.selectedUrl = _0xb503268579;
         self.ok();
      };

      annualGroup.sizer.add(annualPriceLabel);
      annualGroup.sizer.addStretch();
      annualGroup.sizer.add(annualButton);

      let plansSizer = new HorizontalSizer;
      plansSizer.spacing = 12;
      plansSizer.add(monthlyGroup);
      plansSizer.add(annualGroup);

      let bonusGroup = new GroupBox(this);
      bonusGroup.title = "Bonus";
      bonusGroup.sizer = new VerticalSizer;
      bonusGroup.sizer.margin = 12;

      let bonusLabel = new Label(bonusGroup);
      bonusLabel.useRichText = true;
      bonusLabel.wordWrapping = true;
      bonusLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      bonusLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,42,32,66,111,116,104,32,115,117,98,115,99,114,105,112,116,105,111,110,115,32,105,110,99,108,117,100,101,32,97,99,99,101,115,115,32,116,111,32,116,104,101,32) +
         "Premium area with exclusive learning videos<br>" +
         "and early access to new tools.</p>" +
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,42,32,84,104,101,32,97,110,110,117,97,108,32,115,117,98,115,99,114,105,112,116,105,111,110,32,105,110,99,108,117,100,101,115,32,97,99,99,101,115,115,32) +
         "to a questions and answers channel.</b></p>";
      bonusGroup.sizer.add(bonusLabel);

      let transferGroup = new GroupBox(this);
      transferGroup.title = String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101);
      transferGroup.visible = paidRecoveryAvailable;
      transferGroup.sizer = new VerticalSizer;
      transferGroup.sizer.margin = 12;
      transferGroup.sizer.spacing = 10;

      let transferLabel = new Label(transferGroup);
      transferLabel.useRichText = true;
      transferLabel.wordWrapping = true;
      transferLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      transferLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,87,111,117,108,100,32,121,111,117,32,108,105,107,101,32,116,111,32,116,114,97,110,115,102,101,114,32,121,111,117,114,32,108,105,99,101,110,115,101,32,116,111,32,97,110,111,116,104,101,114,32,99,111,109,112,117,116,101,114,63,60,98,114,62) +
         "Open InNova Integrator on the other computer and click this button.</p>";

      let recoveryButton = new PushButton(transferGroup);
      recoveryButton.text = String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101);
      recoveryButton.icon = this.scaledResource( ":/icons/internet.png" );
      recoveryButton.toolTip =
         "Authorize this computer with the purchasing Wix account. No payment is made.";
      recoveryButton.onClick = function ()
      {
         self.recoverExisting = true;
         self.ok();
      };

      let recoverySizer = new HorizontalSizer;
      recoverySizer.addStretch();
      recoverySizer.add(recoveryButton);
      recoverySizer.addStretch();
      transferGroup.sizer.add(transferLabel);
      transferGroup.sizer.add(recoverySizer);

      let supportGroup = new GroupBox(this);
      supportGroup.title = String.fromCharCode(83,117,112,112,111,114,116,32,76,105,99,101,110,115,101,32,82,101,99,111,118,101,114,121);
      supportGroup.visible = paidRecoveryAvailable;
      supportGroup.sizer = new VerticalSizer;
      supportGroup.sizer.margin = 12;
      supportGroup.sizer.spacing = 10;

      let supportLabel = new Label(supportGroup);
      supportLabel.useRichText = true;
      supportLabel.wordWrapping = true;
      supportLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      supportLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,85,115,101,32,116,104,105,115,32,111,112,116,105,111,110,32,119,104,101,110,32,97,32,99,117,114,114,101,110,116,108,121,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,97,110,110,111,116,32) +
         "be recovered normally. Wix will verify the paid period automatically.</p>";

      let supportButton = new PushButton(supportGroup);
      supportButton.text = String.fromCharCode(82,101,99,111,118,101,114,32,76,105,99,101,110,115,101,32,119,105,116,104,32,83,117,112,112,111,114,116);
      supportButton.icon = this.scaledResource( ":/icons/internet.png" );
      supportButton.toolTip =
         "Creates a 30-minute Linking Code for automatic paid-period recovery. No payment is made.";
      supportButton.onClick = function ()
      {
         self.supportRecovery = true;
         self.ok();
      };
      let supportSizer = new HorizontalSizer;
      supportSizer.addStretch();
      supportSizer.add(supportButton);
      supportSizer.addStretch();
      supportGroup.sizer.add(supportLabel);
      supportGroup.sizer.add(supportSizer);

      let cancelButton = new PushButton(this);
      cancelButton.text = "Cancel";
      cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      cancelButton.setFixedWidth(120);
      cancelButton.onClick = function () { self.cancel(); };

      let cancelSizer = new HorizontalSizer;
      cancelSizer.addStretch();
      cancelSizer.add(cancelButton);
      cancelSizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 14;
      this.sizer.spacing = 12;
      this.sizer.add(titleLabel);
      this.sizer.add(plansSizer);
      this.sizer.add(bonusGroup);


      this.sizer.add(transferGroup);
      this.sizer.add(supportGroup);
      this.sizer.add(cancelSizer);

      this.adjustToContents();
      this.setFixedSize();
   }
}


class IntegratorDialog extends Dialog {

    constructor() {

        super();

        this.windowTitle = ProjecTname;

    var self = this;


    function createIntegrationOptionRadioButton(parent) {
       let container = new Control(parent);
       container.sizer = new HorizontalSizer;
       container.sizer.margin = 0;
       container.sizer.spacing = 0;

       let radioButton = new RadioButton(container);
       container.sizer.add(radioButton);
       radioButton.integrationOptionContainer = container;
       radioButton.checkedBeforeInteraction = false;

       radioButton.onMousePress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       radioButton.onKeyPress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       return radioButton;
    }

    function preserveIntegrationOptionToggle(radioButton) {
       let originalOnClick = radioButton.onClick;

       radioButton.onClick = function () {

          this.checked = !this.checkedBeforeInteraction;
          this.checkedBeforeInteraction = this.checked;

          if (originalOnClick)
             originalOnClick.call(this);
       };
    }

    function addIntegrationOption(sizer, radioButton) {
       sizer.add(radioButton.integrationOptionContainer);
    }


    this.userResizable = true;

    this.scaledMinWidth = 620;
    this.scaledMinHeight = 650;


    this.tabBox = new TabBox(this);


    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;


    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;


    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = "2. Gradients:";
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    this.ImageSolverCheckBox = new CheckBox(this.integrationPage);
    this.ImageSolverCheckBox.text = "Run ImageSolver";
    this.ImageSolverCheckBox.checked = false;
    this.ImageSolverCheckBox.enabled = true;
    this.ImageSolverCheckBox.toolTip =
       "Run ImageSolver on every selected project image before processing.";

    this.ImageSolverCheckBox.onClick = function () {
       OptionImageSolver = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ Run ImageSolver = " + OptionImageSolver);
       this.dialog.update();
    };

    this.gradientCorrectionLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientCorrectionLabel.text = "Select gradient correction:";
    this.gradientCorrectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.gradientCorrectionComboBox = new ComboBox(this.CropprojectTypeGroupBox);
    this.gradientCorrectionComboBox.addItem("Run Gradient Correction");
    this.gradientCorrectionComboBox.addItem("Run Multiscale Gradient Correction");
    this.gradientCorrectionComboBox.currentItem = 0;
    this.gradientCorrectionComboBox.setScaledMinWidth(240);

    this.gradientCorrectionComboBox.onItemSelected = function (itemIndex) {
       if (itemIndex === 0) {
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.noteln("⚙️ Gradient Correction = ON");
          console.noteln("⚙️ Multiscale Gradient Correction : OFF");
          return;
       }

       new MessageBox(
          "Remember to adjust the SFC parameters using the 'Settings' button before running the script.\n\n" +
          "MGC requires SFC calibration, MARS and Gaia DR3/SP databases.",
          "Multiscale Gradient Correction",
          StdIcon_Information,
          StdButton_Ok
       ).execute();

       try {
          new MultiscaleGradientCorrection();
          console.noteln("🟢 MultiscaleGradientCorrection is available.");
       } catch (error) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
          new MessageBox(
             "MultiscaleGradientCorrection is not available in this PixInsight version.",
             "InNova Integrator",
             StdIcon_Error,
             StdButton_Ok
          ).execute();
          return;
       }

       if (!MiraValidateMgcConfiguration(true)) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          return;
       }

       OptionGradient = "OFF";
       OptionMgc = "ON";
       console.noteln("⚙️ Gradient Correction = OFF");
       console.noteln("⚙️ Multiscale Gradient Correction : ON");
    };


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionLabel);
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionComboBox);
    this.gradientSettingsLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientSettingsLabel.text = "Clic on 'Settings' for SFC and MGC options";
    this.gradientSettingsLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientSettingsLabel);
    this.CropprojectTypeGroupBox.adjustToContents();
    this.CropprojectTypeGroupBox.setFixedHeight(
       this.CropprojectTypeGroupBox.height
    );


    this.HalphaCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.HalphaCheckBox.text = "Create 'HAlpha' for blending (RGB/LRGB)";
    this.HalphaCheckBox.checked = false;


    function MiraComboProyect() {

    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].enabled = false;
        self.comboBoxReferences[key].update();
    }


    switch (ProjecTypevar) {
        case "RGB":
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "LRGB":
            self.comboBoxReferences["PimageLuminance"].enabled = true;
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "SHO":
            self.comboBoxReferences["PimageSii"].enabled = true;
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "HOO":
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "OSC":
            self.comboBoxReferences["PimageOsc"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }


    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].update();
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "1. Project:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    let imageSolverWasEnabledBeforeVaonis = false;
    let imageSolverWasCheckedBeforeVaonis = false;
    let imageSolverForcedByVaonis = false;

    function selectProjectType(projectType, enableFast, vaonisMode,
                               seestarMode) {
       ProjecTypevar = projectType;
       let smartTelescopeMode = vaonisMode || seestarMode;
       OptionSeestar = seestarMode ? "ON" : "OFF";

       OptionVaonisVespera = smartTelescopeMode ? "ON" : "OFF";

       if (self.oscImageLabel) {
          self.oscImageLabel.text = seestarMode ? "SEESTAR:" :
             (vaonisMode ? "VAONIS Vespera:" : "OSC Image:");
          self.oscImageLabel.update();
       }

       if (smartTelescopeMode && OptionObjectType === "STARS") {
          if (!imageSolverForcedByVaonis) {
             imageSolverWasEnabledBeforeVaonis = self.ImageSolverCheckBox.enabled;
             imageSolverWasCheckedBeforeVaonis = self.ImageSolverCheckBox.checked;
          }

          self.ImageSolverCheckBox.checked = true;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "ON";
          imageSolverForcedByVaonis = true;
          console.noteln("⚙️ " +
             (seestarMode ? "SEESTAR" : "VAONIS Vespera") +
             " mode: interactive ImageSolver enabled.");
       }
       else if (imageSolverForcedByVaonis) {
          self.ImageSolverCheckBox.enabled = imageSolverWasEnabledBeforeVaonis;
          self.ImageSolverCheckBox.checked = imageSolverWasCheckedBeforeVaonis;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = false;
       }

       if (OptionObjectType === "MOON_SUN") {
          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;
       }

       self.FastCheckBox.enabled = enableFast;
       if (!enableFast) {
          self.FastCheckBox.checked = false;
          self.FastCheckBox.text = "Fast integration mode 'OFF' ";
          self.FastCheckBox.styleSheet = "color: black;";
          OptionFast = "OFF";
       }

       let narrowbandProject = projectType === "SHO" || projectType === "HOO";
       let rgbProject = projectType === "RGB" || projectType === "LRGB";

       if (self.finalStarsComboBox && !narrowbandProject &&
           self.finalStarsComboBox.currentItem === 2) {
          self.finalStarsComboBox.currentItem = 0;
          Option1var = "OFF";
          OptionHSOvar = "OFF";
       }

       if (self.HalphaCheckBox) {
          self.HalphaCheckBox.enabled = rgbProject;
          if (!rgbProject) {
             self.HalphaCheckBox.checked = false;
             OptionHavar = "OFF";
          }
       }

       MiraComboProyect();
       self.update();
    }

    this.projectTypeComboBox = new ComboBox(this.projectTypeGroupBox);
    this.projectTypeComboBox.addItem("LRGB");
    this.projectTypeComboBox.addItem("RGB");
    this.projectTypeComboBox.addItem("SHO");
    this.projectTypeComboBox.addItem("HOO");
    this.projectTypeComboBox.addItem("OSC (RGB Color camera .xisf or Raw)");
    this.projectTypeComboBox.addItem("SEESTAR (.fit)");
    this.projectTypeComboBox.addItem("VAONIS VESPERA (.tiff)");
    this.projectTypeComboBox.currentItem = 2;
    this.projectTypeComboBox.setScaledMinWidth(240);
    this.projectTypeComboBox.toolTip =
       "Select the project type. SEESTAR and VAONIS VESPERA TIFF modes " +
       "automatically open ImageSolver when an astrometric solution is required.";

    this.projectTypeComboBox.onItemSelected = function (itemIndex) {
       let projectTypes = [
          "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC"
       ];
       let enableFast = itemIndex < 4;
       selectProjectType(
          projectTypes[itemIndex], enableFast,
          itemIndex === 6, itemIndex === 5);
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;
    this.projectTypeLabel = new Label(this.projectTypeGroupBox);
    this.projectTypeLabel.text = "Select project type:";
    this.projectTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.projectTypeGroupBox.sizer.add(this.projectTypeLabel);
    this.projectTypeGroupBox.sizer.add(this.projectTypeComboBox);
    this.projectTypeGroupBox.sizer.add(this.ImageSolverCheckBox);
    this.projectTypeGroupBox.adjustToContents();
    this.projectTypeGroupBox.setFixedHeight(this.projectTypeGroupBox.height);


    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.CropprojectTypeGroupBox);


    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "3. Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    self.comboBoxReferences = {};


    let taggingLabelWidth = this.font.width("Luminance Image:M");

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer;
       rowSizer.spacing = 6;

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(taggingLabelWidth);

       if (variableKey === "PimageOsc")
          self.oscImageLabel = label;

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem("<Select an Image>");

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];

           if (!window || window.isNull || !window.mainView || window.mainView.isNull)
               continue;


           comboBox.addItem(window.mainView.id);
       }

       self.comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = index === 0 ? "EMPTY" : comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
       };


       rowSizer.add(label);
       rowSizer.add(comboBox, 1);


       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;


      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Sii Image:", "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Ha Image:", "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Oiii Image:", "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Red Image:", "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Green Image:", "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Blue Image:", "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Luminance Image:", "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "OSC Image:", "PimageOsc");
      this.taggingGroupBox.sizer.addSpacing(6);


    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "4. Object:";
    this.optionsGroupBox.sizer = new VerticalSizer;


    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;


      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };


   this.FastCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
   this.FastCheckBox.text = "Fast integration mode 'OFF' ";
   this.FastCheckBox.checked = false;

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = "Fast integration mode 'ON' ";
           this.styleSheet = "color: blue;";
           console.writeln("⚙️ Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionFast = "OFF";
           this.text = "Fast integration mode 'OFF' ";
           this.styleSheet = "color: black;";
           console.noteln("⚙️ Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


    this.darkStructureEnhanceCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.darkStructureEnhanceCheckBox.text =
       "InNova Dark Structure Enhance";
    this.darkStructureEnhanceCheckBox.checked = true;
    this.darkStructureEnhanceCheckBox.onClick = function () {
        OptionDarkStructureEnhance = this.checked ? "ON" : "OFF";
        console.noteln("⚙️ InNova Dark Structure Enhance: " +
                       OptionDarkStructureEnhance);
    };

    this.finalStarRefinementCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.finalStarRefinementCheckBox.text = "InNova Star Refinement";
    this.finalStarRefinementCheckBox.checked = false;
    this.finalStarRefinementCheckBox.enabled = false;
    this.finalStarRefinementCheckBox.onClick = function () {
       if (this.checked && OptionVarStars !== "ON") {
          this.checked = false;
          OptionFinalStarRefinement = "OFF";
          console.warningln(
             "⚠️ InNova Star Refinement requires a Final_starless method.");
          return;
       }
       OptionFinalStarRefinement = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ InNova Star Refinement: " +
                      OptionFinalStarRefinement);
    };

    this.resolutionCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.resolutionCheckBox.text = "300ppi Print Resolution";
    this.resolutionCheckBox.checked = false;
    this.resolutionCheckBox.onClick = function () {

          if (this.checked) {
              Option300 = "ON";
              console.noteln("⚙️ 300ppi Print Resolution: ON");
          } else {
              Option300 = "OFF";
              console.noteln("⚙️ 300ppi Print Resolution: OFF");
          }

      };


    ProjecTypevar = "SHO";
    MiraComboProyect();


    this.OptionVarStarsCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.OptionVarStarsCheckBox.integrationOptionContainer.visible = false;
    this.starsHSOCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsHSOCheckBox.integrationOptionContainer.visible = false;


    this.starsRGBCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsRGBCheckBox.text = "Create RGB 'Final_stars' (SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    var self = this;


    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.warningln("\n⚠️ Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


    if (!this.checked) {
        Option1var = "OFF";
        console.noteln("⚙️ Create RGB 'Final_stars' : OFF");
        return;
    }


    let msgBox = new MessageBox("Enable RGB Images for stars?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
            OptionHSOvar = "OFF";
            self.starsHSOCheckBox.checked = false;

            ProjecTypevar2 = "1";
            self.starsRGBCheckBox.checked = true;

    } else {

        self.comboBoxReferences["PimageRed"].enabled = false;
        self.comboBoxReferences["PimageGreen"].enabled = false;
        self.comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        Option1var = "OFF";
        self.update();
    }
};


var self = this;


self.starXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
self.starXterminatorCheckBox.text = "Create Starless by StarXTerminator";
self.starXterminatorCheckBox.checked = true;


this.starNetCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
this.starNetCheckBox.text = "Create Starless by StarNet2";
this.starNetCheckBox.checked = false;


this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           if (starXterminatorInstalled) {
              self.starXterminatorCheckBox.checked = true;
              self.starNetCheckBox.checked = false;
              OptionStarXterminator = "ON";
           } else if (starNet2Installed) {
              self.starXterminatorCheckBox.checked = false;
              self.starNetCheckBox.checked = true;
              OptionStarXterminator = "OFF";
           } else {
              this.checked = false;
              OptionVarStars = "OFF";
              OptionStarXterminator = "OFF";
              console.warningln("⚠️ StarXTerminator or StarNet2 must be installed to create a starless image.");
              return;
           }

           OptionVarStars = "ON";
           console.noteln("⚙️ Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = starXterminatorInstalled;
           self.starNetCheckBox.enabled = starNet2Installed;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           OptionHSOvar = "ON";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("⚙️ Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = false;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "OFF";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           OptionHSOvar = "OFF";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };


let starRemovalMethodLabel = "Star Removal by StarXterminator";
OptionStarXterminator = "ON";


self.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        if (!starXterminatorInstalled) {
            this.checked = false;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";

        console.writeln("Fast Process !!!");
    } else {
        if (!starNet2Installed) {
            this.checked = true;
            OptionStarXterminator = "ON";
            console.warningln("⚠️ StarNet2 is not installed. StarXTerminator remains selected.");
            return;
        }


        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};


this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        if (!starNet2Installed) {
            this.checked = false;
            console.warningln("⚠️ StarNet2 is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        console.writeln("Slow Process !!!");
    } else {
        if (!starXterminatorInstalled) {
            this.checked = true;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed. StarNet2 remains selected.");
            return;
        }


        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};


    this.blurXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.blurXterminatorCheckBox.text = "Sharpen by BlurXTerminator";
    this.blurXterminatorCheckBox.checked = true;


    this.highPassCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.highPassCheckBox.text = "Sharpen by InNova Focus";
    this.highPassCheckBox.checked = false;


    this.HalphaCheckBox.onClick = function () {

    if (ProjecTypevar !== "RGB" && ProjecTypevar !== "LRGB") {
      console.warningln("⚠️ Invalid Project type selected. 'RGB' or 'LRGB' type project, not selected.");
      self.HalphaCheckBox.checked = false;
    return;
    }


    OptionHavar = this.checked ? "ON" : "OFF";
    self.HalphaCheckBox.checked = false;


    let msgBox = new MessageBox("Enable Ha Image for blending?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageHa"].enabled = true;
            self.HalphaCheckBox.checked = true;
            OptionHavar = "ON";


    } else {

        self.comboBoxReferences["PimageHa"].enabled = false;
        self.HalphaCheckBox.checked = false;
        OptionHavar = "OFF";
        self.update();
    }
};

    this.blurXterminatorCheckBox.onClick = function () {
        if (this.checked && !blurXterminatorInstalled) {
           this.checked = false;
           self.highPassCheckBox.checked = true;
           OptionBlurXterminator = "OFF";
           OptionHighpass = "ON";
           console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus remains enabled.");
           return;
        }

        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {

         self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
         OptionHighpass = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");

           } else {

         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
         OptionHighpass = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator : ON");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";

         if (!this.checked && !blurXterminatorInstalled) {
            this.checked = true;
            self.blurXterminatorCheckBox.checked = false;
            OptionHighpass = "ON";
            OptionBlurXterminator = "OFF";
            console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus is required.");
            return;
         }

         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: ON. InNova Focus disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");
       }
      };


    let legacyHiddenControls = [
       this.OptionVarStarsCheckBox,
       this.starsHSOCheckBox,
       this.starsRGBCheckBox,
       self.starXterminatorCheckBox,
       this.starNetCheckBox,
       this.blurXterminatorCheckBox,
       this.highPassCheckBox,
       this.darkStructureEnhanceCheckBox,
       this.finalStarRefinementCheckBox
    ];
    for (let i = 0; i < legacyHiddenControls.length; ++i)
       legacyHiddenControls[i].integrationOptionContainer.visible = false;

    let integrationOptionRadioButtons = [
       this.FastCheckBox,
       this.HalphaCheckBox,
       this.resolutionCheckBox
    ];

    for (let i = 0; i < integrationOptionRadioButtons.length; ++i)
       preserveIntegrationOptionToggle(integrationOptionRadioButtons[i]);


    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 4;

    function addThirdPartyCombo(combo, items) {
       combo.setScaledMinWidth(240);
       for (let i = 0; i < items.length; ++i)
          combo.addItem(items[i]);
       combo.currentItem = 0;
       self.optionsGroupBox.sizer.add(combo);
    }

    function warnMissingThirdPartyPlugin(pluginName) {
       console.warningln("⚠️ " + pluginName +
          " plugin is not installed. Choose another option.");
    }

    this.objectTypeLabel = new Label(this.optionsGroupBox);
    this.objectTypeLabel.text = "Object Type:";
    this.objectTypeLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.objectTypeLabel);

    this.objectTypeComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.objectTypeComboBox, [
       "Stars",
       "Moon / Sun"
    ]);
    this.objectTypeComboBox.toolTip =
       "Stars uses the normal astrometry and star-processing workflow. " +
       "Moon / Sun skips ImageSolver and all star-dependent processes.";

    this.optionsGroupBox.sizer.addSpacing(3);

    this.starlessImageLabel = new Label(this.optionsGroupBox);
    this.starlessImageLabel.text = "Starless Image:";
    this.starlessImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.starlessImageLabel);

    this.starlessMethodComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.starlessMethodComboBox, [
       "No create 'Final_starless'",
       "Create 'Final_starless' by StarXTerminator",
       "Create 'Final_starless' by StarXNet2"
    ]);

    this.optionsGroupBox.sizer.addSpacing(3);
    this.finalStarsImageLabel = new Label(this.optionsGroupBox);
    this.finalStarsImageLabel.text = "Final stars Image:";
    this.finalStarsImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.finalStarsImageLabel);

    this.finalStarsComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.finalStarsComboBox, [
       "<Create 'Final_stars' image (Project stars)>",
       "Create 'Final_stars' image (Project stars)",
       "Create RGB 'Final_stars' (SHO/HOO)"
    ]);
    this.finalStarsComboBox.enabled = false;

    function resetFinalStarsSelection() {
       self.finalStarsComboBox.currentItem = 0;
       OptionHSOvar = "OFF";
       Option1var = "OFF";
       self.finalStarRefinementCheckBox.checked = false;
       self.finalStarRefinementCheckBox.enabled = false;
       OptionFinalStarRefinement = "OFF";
       FinalStarRefinementReady = false;
       MiraComboProyect();
    }

    function enableFinalStarRefinement() {
       self.finalStarRefinementCheckBox.enabled = true;
       self.finalStarRefinementCheckBox.checked = true;
       OptionFinalStarRefinement = "ON";
       FinalStarRefinementReady = false;
    }

    let objectModeSavedImageSolverChecked =
       this.ImageSolverCheckBox.checked;

    function applyObjectTypeMode(itemIndex, announce) {
       let moonSunMode = itemIndex === 1;
       OptionObjectType = moonSunMode ? "MOON_SUN" : "STARS";

       if (moonSunMode) {
          objectModeSavedImageSolverChecked =
             self.ImageSolverCheckBox.checked;

          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;

          self.gradientCorrectionComboBox.currentItem = 0;
          self.gradientCorrectionComboBox.enabled = false;
          OptionGradient = "ON";
          OptionMgc = "OFF";

          self.starlessMethodComboBox.currentItem = 0;
          self.starlessMethodComboBox.enabled = false;
          self.starlessImageLabel.enabled = false;
          self.finalStarsImageLabel.enabled = false;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          OptionVarStars = "OFF";
          OptionStarXterminator = "OFF";
          OptionFinalStarRefinement = "OFF";
          OptionHavar = "OFF";

          if (self.HalphaCheckBox) {
             self.HalphaCheckBox.checked = false;
             self.HalphaCheckBox.enabled = false;
          }

          if (announce !== false)
             console.noteln(
                "🌙 Moon / Sun mode: ImageSolver, MGC and star-dependent " +
                "processes are disabled.");
       }
       else {
          self.starlessMethodComboBox.enabled = true;
          self.starlessImageLabel.enabled = true;
          self.finalStarsImageLabel.enabled = true;
          self.finalStarsComboBox.enabled = false;
          self.gradientCorrectionComboBox.enabled = true;

          let smartTelescopeMode =
             self.projectTypeComboBox.currentItem === 5 ||
             self.projectTypeComboBox.currentItem === 6;
          self.ImageSolverCheckBox.checked = smartTelescopeMode ?
             true : objectModeSavedImageSolverChecked;
          self.ImageSolverCheckBox.enabled = !smartTelescopeMode;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = smartTelescopeMode;

          let selectedProject = [
             "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC"
          ][self.projectTypeComboBox.currentItem];
          let rgbProject = selectedProject === "RGB" ||
             selectedProject === "LRGB";
          self.HalphaCheckBox.enabled = rgbProject;

          if (announce !== false)
             console.noteln(
                "⭐ Stars mode: normal astrometry and star processing enabled.");
       }

       self.ImageSolverCheckBox.update();
       self.gradientCorrectionComboBox.update();
       self.starlessMethodComboBox.update();
       self.finalStarsComboBox.update();
       self.update();
    }

    this.objectTypeComboBox.onItemSelected = function (itemIndex) {
       applyObjectTypeMode(itemIndex, true);
    };

    this.starlessMethodComboBox.onItemSelected = function (itemIndex) {
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionVarStars = "OFF";
       OptionStarXterminator = "OFF";

       if (itemIndex === 1 && !starXterminatorInstalled) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarXTerminator");
          return;
       }

       if (itemIndex === 2 && !starNet2Installed) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarNet2");
          return;
       }

       if (itemIndex === 0) {
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          console.noteln("⚙️ Final_starless creation: OFF");
          return;
       }

       OptionVarStars = "ON";
       OptionStarXterminator = itemIndex === 1 ? "ON" : "OFF";
       self.finalStarsComboBox.enabled = true;


       self.finalStarsComboBox.currentItem = 1;
       OptionHSOvar = "ON";
       Option1var = "OFF";
       enableFinalStarRefinement();
       MiraComboProyect();
       console.noteln("⚙️ Final_starless method: " +
          (itemIndex === 1 ? "StarXTerminator" : "StarNet2"));
       console.noteln("⚙️ Final_stars: Project stars (default)");
    };

    this.finalStarsComboBox.onItemSelected = function (itemIndex) {
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionHSOvar = "OFF";
       Option1var = "OFF";

       if (itemIndex === 0) {
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
          console.noteln("⚙️ Final_stars creation: OFF");
          return;
       }

       if (OptionVarStars !== "ON") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ Select a Final_starless method first.");
          return;
       }

       if (itemIndex === 1) {
          OptionHSOvar = "ON";
          enableFinalStarRefinement();
          MiraComboProyect();
          console.noteln("⚙️ Final_stars: Project stars");
          return;
       }

       if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ RGB Final_stars is only available for SHO and HOO projects.");
          return;
       }

       let msgBox = new MessageBox(
          "Enable RGB Images for stars?",
          "Confirmation",
          StdIcon_Question,
          StdButton_Yes,
          StdButton_No
       );

       if (msgBox.execute() === StdButton_Yes) {
          self.comboBoxReferences["PimageRed"].enabled = true;
          self.comboBoxReferences["PimageGreen"].enabled = true;
          self.comboBoxReferences["PimageBlue"].enabled = true;
          Option1var = "ON";
          ProjecTypevar2 = "1";
          enableFinalStarRefinement();
          console.noteln("⚙️ Final_stars: RGB stars");
       }
       else {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
       }
    };


    this.finalOptionsGroupBox = new GroupBox(this.integrationPage);
    this.finalOptionsGroupBox.title = "5. Options:";
    this.finalOptionsGroupBox.sizer = new VerticalSizer;
    this.finalOptionsGroupBox.sizer.margin = 6;
    this.finalOptionsGroupBox.sizer.spacing = 3;


    this.finalOptionsGroupBox.sizer.addSpacing(10);
    this.finalOptionsGroupBox.sizer.add(this.linkRGBChannels);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.FastCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.HalphaCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.resolutionCheckBox);


    this.optionsGroupBox.adjustToContents();
    this.finalOptionsGroupBox.adjustToContents();
    let commonOptionsGroupHeight = Math.max(
       this.optionsGroupBox.height,
       this.finalOptionsGroupBox.height);
    this.optionsGroupBox.setFixedHeight(commonOptionsGroupHeight);
    this.finalOptionsGroupBox.setFixedHeight(commonOptionsGroupHeight);

    this.optionsGroupsSizer = new HorizontalSizer;
    this.optionsGroupsSizer.spacing = 10;
    this.optionsGroupsSizer.add(this.optionsGroupBox);
    this.optionsGroupsSizer.add(this.finalOptionsGroupBox);


    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;


      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)] = new Control(this);
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer = new VerticalSizer;
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.margin = 10;
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.spacing = 6;

      let _0x1063dbbebd = new GroupBox(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)]);
      _0x1063dbbebd.title = String.fromCharCode(76,105,99,101,110,115,101,32,73,110,102,111,114,109,97,116,105,111,110);
      _0x1063dbbebd.sizer = new VerticalSizer;
      _0x1063dbbebd.sizer.margin = 6;
      _0x1063dbbebd.sizer.spacing = 4;

      let emailLabel = new Label(this);
      emailLabel.text = "Email:";
      emailLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      emailLabel.setFixedWidth(105);

      this.emailEdit = new Edit(this);
      this.emailEdit.minWidth = 300;
      this.emailEdit.text = "";
      this.emailEdit.enabled = false;

      let emailSizer = new HorizontalSizer;
      emailSizer.spacing = 8;
      emailSizer.add(emailLabel);
      emailSizer.add(this.emailEdit, 1);
      _0x1063dbbebd.sizer.add(emailSizer);

      let codeLabel = new Label(this);
      codeLabel.text = "Code:";
      codeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      codeLabel.setFixedWidth(105);

      this.codeEdit = new Edit(this);
      this.codeEdit.minWidth = 300;
      this.codeEdit.text = "";
      this.codeEdit.enabled = false;

      let codeSizer = new HorizontalSizer;
      codeSizer.spacing = 8;
      codeSizer.add(codeLabel);
      codeSizer.add(this.codeEdit, 1);
      _0x1063dbbebd.sizer.add(codeSizer);

      let _0x109776f1cb = new Label(this);
      _0x109776f1cb.text = String.fromCharCode(69,120,112,105,114,121,58);
      _0x109776f1cb.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      _0x109776f1cb.setFixedWidth(105);

      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)] = new Edit(this);
      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].minWidth = 300;
      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = "";
      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].enabled = false;

      let _0x6170aa8263 = new HorizontalSizer;
      _0x6170aa8263.spacing = 8;
      _0x6170aa8263.add(_0x109776f1cb);
      _0x6170aa8263.add(this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)], 1);
      _0x1063dbbebd.sizer.add(_0x6170aa8263);

      let _0x1f90275dcd = new Label(this);
      _0x1f90275dcd.text = String.fromCharCode(77,97,99,104,105,110,101,32,73,68,58);
      _0x1f90275dcd.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      _0x1f90275dcd.setFixedWidth(105);

      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)] = new Edit(this);
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].minWidth = 300;
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text = _0x8755f000a9();
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].enabled = true;
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].readOnly = true;

      let _0x934cb24329 = new HorizontalSizer;
      _0x934cb24329.spacing = 8;
      _0x934cb24329.add(_0x1f90275dcd);
      _0x934cb24329.add(this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)], 1);
      _0x1063dbbebd.sizer.add(_0x934cb24329);

      let signatureLabel = new Label(this);
      signatureLabel.text = "Signature:";
      signatureLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      signatureLabel.setFixedWidth(105);

      this.signatureEdit = new Edit(this);
      this.signatureEdit.minWidth = 300;
      this.signatureEdit.text = "";
      this.signatureEdit.enabled = false;
      this.signatureEdit.toolTip = String.fromCharCode(80,97,115,116,101,32,116,104,101,32,99,111,109,112,108,101,116,101,32,108,105,99,101,110,115,101,32,115,105,103,110,97,116,117,114,101,46);

      let signatureSizer = new HorizontalSizer;
      signatureSizer.spacing = 8;
      signatureSizer.add(signatureLabel);
      signatureSizer.add(this.signatureEdit, 1);
      _0x1063dbbebd.sizer.add(signatureSizer);

      let profileNoteControl = new Control(_0x1063dbbebd);
      profileNoteControl.visible = false;
      let NotaLabel = new Label(profileNoteControl);
      NotaLabel.text = String.fromCharCode(42,32,67,108,105,99,107,32,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,32,116,111,32,99,97,110,99,101,108,32,111,114,32,99,104,97,110,103,101,32,121,111,117,114,32,99,117,114,114,101,110,116,32,115,117,98,115,99,114,105,112,116,105,111,110,46);
      NotaLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      NotaLabel.adjustToContents();
      let profileNoteSizer = new HorizontalSizer;
      profileNoteSizer.spacing = 0;
      profileNoteSizer.add(NotaLabel);
      profileNoteSizer.addStretch();
      let profileNoteLayout = new VerticalSizer;
      profileNoteLayout.margin = 0;
      profileNoteLayout.spacing = 0;
      profileNoteLayout.addSpacing(12);
      profileNoteLayout.add(profileNoteSizer);
      profileNoteLayout.addSpacing(4);
      profileNoteControl.sizer = profileNoteLayout;
      profileNoteControl.setFixedHeight(16 + NotaLabel.height);


      let firstPurchaseControlsRequested = false;
      let purchaseStepButtonStates = null;
      let accountLinkControl = new Control(_0x1063dbbebd);
      accountLinkControl.visible = false;
      let linkLabel = new Label(accountLinkControl);
      linkLabel.text = "Linking code:";
      linkLabel.setFixedWidth(105);
      this.accountLinkEdit = new Edit(accountLinkControl);
      this.accountLinkEdit.readOnly = true;
      this.accountLinkEdit.text = SoftwareLinkCode();
      this.accountLinkEdit.toolTip = "Copy this code to the InNova website while signed in as the purchaser. Valid for 30 minutes.";
      let accountLinkSizer = new HorizontalSizer;
      accountLinkSizer.spacing = 8;
      accountLinkSizer.add(linkLabel);
      accountLinkSizer.add(this.accountLinkEdit, 1);
      let activatePurchaseButton = new PushButton(accountLinkControl);
      activatePurchaseButton.text = "Activate Purchase";
      activatePurchaseButton.icon = this.scaledResource(":/icons/ok.png");
      activatePurchaseButton.toolTip = String.fromCharCode(65,102,116,101,114,32,112,97,121,109,101,110,116,44,32,99,104,101,99,107,32,87,105,120,32,99,111,110,102,105,114,109,97,116,105,111,110,32,97,110,100,32,100,111,119,110,108,111,97,100,32,121,111,117,114,32,108,105,99,101,110,115,101,46,32,78,111,32,112,114,111,102,105,108,101,32,115,105,103,110,97,116,117,114,101,32,111,114,32,97,100,100,105,116,105,111,110,97,108,32,112,97,121,109,101,110,116,32,105,115,32,110,101,101,100,101,100,32,102,111,114,32,97,32,110,101,119,32,112,117,114,99,104,97,115,101,46);
      activatePurchaseButton.onClick = function () { _0x22db21bd2d(); };
      accountLinkSizer.add(activatePurchaseButton);


      linkLabel.adjustToContents();
      this.accountLinkEdit.adjustToContents();
      activatePurchaseButton.adjustToContents();
      let accountLinkLayout = new VerticalSizer;
      accountLinkLayout.margin = 0;
      accountLinkLayout.spacing = 0;
      accountLinkLayout.addSpacing(8);
      accountLinkLayout.add(accountLinkSizer);
      accountLinkControl.sizer = accountLinkLayout;
      accountLinkControl.setFixedHeight(8 + Math.max(linkLabel.height,
         this.accountLinkEdit.height, activatePurchaseButton.height));


      var self = this;

      let filePath = _0x9f6001fa7d();

      if (File.exists(filePath))
      {
        let _0x6e002bc706 = _0x18533ed6ec();

            if (_0xb860392b3d(_0x6e002bc706))
            {
               self.emailEdit.text = _0x6e002bc706.email;
               self.codeEdit.text = _0x6e002bc706.code;
               self[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = _0x6e002bc706[String.fromCharCode(101,120,112,105,114,121)];
               self.signatureEdit.text = _0x6e002bc706[String.fromCharCode(115,105,103,110,97,116,117,114,101)];
            }
            else
            {
               console.warningln(String.fromCharCode(82,117,110,110,105,110,103,32,105,110,32,116,114,105,97,108,32,109,111,100,101,46));

               self.emailEdit.text = "";
               self.codeEdit.text = "";
               self[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = "";
            }
      }
      else
      {
         self.emailEdit.text = "";
         self.codeEdit.text = "";
      }


      _0x1063dbbebd.sizer.addSpacing(6);


      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;
      buttonSizer.addStretch();


      function CopyTextToSystemClipboard(text)
      {
         let platform = String(CoreApplication.platform).toLowerCase();
         let commands = [];

         if (platform.indexOf("mac") >= 0)
            commands.push(["/usr/bin/pbcopy", []]);
         else if (platform.indexOf("win") >= 0)
            commands.push(["cmd.exe", ["/c", "clip"]]);
         else
         {
            commands.push(["xclip", ["-selection", "clipboard"]]);
            commands.push(["xsel", ["--clipboard", "--input"]]);
         }

         for (let i = 0; i < commands.length; ++i)
         {
            try
            {
               let process = new ExternalProcess;
               process.start(commands[i][0], commands[i][1]);
               if (!process.waitForStarted(3000))
                  continue;

               process.standardInput = text;
               if (!process.waitForDataWritten(3000))
               {
                  process.closeStandardInput();
                  continue;
               }
               process.closeStandardInput();

               if (process.waitForFinished(3000) && process.exitCode === 0)
                  return true;
            }
            catch (error)
            {

            }
         }

         return false;
      }

      function _0x2f3ce02b79(url, browserTitle)
      {

         if (!RequireInNovaServerConnection()) return null;
         let platform = String(CoreApplication.platform).toLowerCase();
         let command;

         if (platform.indexOf("mac") >= 0)
            command = ["/usr/bin/open", [url]];
         else if (platform.indexOf("win") >= 0)
            command = ["cmd.exe", ["/c", "start", "", url]];
         else
            command = ["xdg-open", [url]];

         try
         {
            let process = new ExternalProcess;
            process.start(command[0], command[1]);
            if (process.waitForStarted(3000))
               return true;
         }
         catch (error)
         {

         }

         try
         {
            Dialog.openBrowser(url, browserTitle || String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110));
            return true;
         }
         catch (error)
         {
            return false;
         }
      }

      function _0x80c932676d()
      {
         let mailUrl = "mailto:soporte@teoriadelcolor.net" +
            String.fromCharCode(63,115,117,98,106,101,99,116,61,73,110,78,111,118,97,37,50,48,65,115,116,114,111,37,50,48,45,37,50,48,76,105,99,101,110,115,101,37,50,48,80,114,111,98,108,101,109);
         let platform = String(CoreApplication.platform).toLowerCase();
         let command;

         if (platform.indexOf("mac") >= 0)
            command = ["/usr/bin/open", [mailUrl]];
         else if (platform.indexOf("win") >= 0)
            command = ["cmd.exe", ["/c", "start", "", mailUrl]];
         else
            command = ["xdg-open", [mailUrl]];

         try
         {
            let process = new ExternalProcess;
            process.start(command[0], command[1]);
            if (process.waitForStarted(3000))
               return true;
         }
         catch (error)
         {

         }

         try
         {
            Dialog.openBrowser(mailUrl, String.fromCharCode(73,110,78,111,118,97,32,76,105,99,101,110,115,101,32,83,117,112,112,111,114,116));
            return true;
         }
         catch (error)
         {
            return false;
         }
      }

      function SetPurchaseStepPending(pending)
      {
         if (pending)
         {
            if (purchaseStepButtonStates === null)
               purchaseStepButtonStates = [_0xd31108c6e0.enabled,
                  _0xc1b9439e9e.enabled, _0x76206c0517.enabled,
                  premiumSiteButton.enabled];
            _0xd31108c6e0.enabled = false;
            _0xc1b9439e9e.enabled = false;
            _0x76206c0517.enabled = false;
            premiumSiteButton.enabled = false;
         }
         else if (purchaseStepButtonStates !== null)
         {
            _0xd31108c6e0.enabled = purchaseStepButtonStates[0];
            _0xc1b9439e9e.enabled = purchaseStepButtonStates[1];
            _0x76206c0517.enabled = purchaseStepButtonStates[2];
            premiumSiteButton.enabled = purchaseStepButtonStates[3];
            purchaseStepButtonStates = null;
         }
      }

      function _0x22db21bd2d()
      {


         SetPurchaseStepPending(false);
         firstPurchaseControlsRequested = true;
         try {
            let _0x347c500185 = _0x3472346d4e(self[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text);
            let result = RequestInNovaFirstActivation(_0x347c500185, true);
            self.accountLinkEdit.text = SoftwareLinkCode();
            if (result === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
                !(_0x4c182ff3c0 && _0x4c182ff3c0.pending && _0x4c182ff3c0.pending.autoPurchase)) {
               _0x2ab8232aec("InNova Integrator",
                  "After completing your purchase, authorize this computer.",
                  { firstPurchase: true });
               result = RequestInNovaFirstActivation(_0x347c500185, false);
            }
            if (result === "ACTIVATED") {
               let saved = _0x18533ed6ec();
               self.emailEdit.text = saved.email;
               self.codeEdit.text = saved.code;
               self[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = saved[String.fromCharCode(101,120,112,105,114,121)];
               self.signatureEdit.text = saved[String.fromCharCode(115,105,103,110,97,116,117,114,101)];
               self.accountLinkEdit.text = SoftwareLinkCode();
               _0x2ec0322bf9 = saved[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
               _0x7fbd7dc1d0 = _0xae2bfdb8ee(saved[String.fromCharCode(101,120,112,105,114,121)]) ? "FULL_GRACE" : "FULL";
               _0x1edc0a1ae1();
               self.runButton.enabled = CanProcess();
               if (_0x7fbd7dc1d0 === "FULL_GRACE") _0xa3650bb7b1("InNova Integrator", saved, true);
               else new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,112,117,114,99,104,97,115,101,100,32,108,105,99,101,110,115,101,32,105,115,32,110,111,119,32,97,99,116,105,118,97,116,101,100,46,60,47,112,62),
                  "InNova Integrator", StdIcon_Information, StdButton_Ok).execute();
            } else if (result === "PAYMENT_PENDING") {
               new MessageBox("<p align=\"center\">Wix has not yet confirmed your purchase.<br/><br/>" +
                  "If you have completed payment, wait a moment and click <b>Activate Purchase</b> again.<br/>" +
                  "<b>Do not pay again.</b> No website signature is required for this first purchase.</p>",
                  "InNova Integrator", StdIcon_Information, StdButton_Ok).execute();
            } else if (result === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
                       _0x4c182ff3c0 && _0x4c182ff3c0.pending && _0x4c182ff3c0.pending.autoPurchase) {
               throw new Error(String.fromCharCode(84,104,105,115,32,112,117,114,99,104,97,115,101,32,114,101,113,117,105,114,101,115,32,97,99,99,111,117,110,116,32,114,101,99,111,118,101,114,121,32,111,114,32,114,101,110,101,119,97,108,32,97,117,116,104,111,114,105,122,97,116,105,111,110,46,32,67,111,110,116,97,99,116,32,73,110,78,111,118,97,32,115,117,112,112,111,114,116,59,32,100,111,32,110,111,116,32,112,97,121,32,97,103,97,105,110,46));
            } else if (result !== String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68)) {
               throw new Error("Activation status: " + result);
            }
         } catch (error) {
            if (error.innovaServerUnavailable) return;
            new MessageBox("Purchase activation could not be completed.\n\n" +
               "Check your connection and retry. Contact InNova support if the problem persists.\n" +
               "Do not purchase again.\n\n" + String(error.message || error),
               "InNova Integrator", StdIcon_Warning, StdButton_Ok).execute();
         } finally {
            UpdatePurchaseActivationControls();
         }
      }

      let _0xd31108c6e0 = new PushButton(this);
      _0xd31108c6e0.text = String.fromCharCode(77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110);
      _0xd31108c6e0.icon =
         this.scaledResource( ":/icons/clipboard-internet.png" );
      _0xd31108c6e0.setFixedWidth(190);
      _0xd31108c6e0.setFixedHeight(WindowsOsx1 + 5);
      _0xd31108c6e0.toolTip =
         String.fromCharCode(80,117,114,99,104,97,115,101,32,121,111,117,114,32,102,105,114,115,116,32,115,117,98,115,99,114,105,112,116,105,111,110,32,111,114,32,111,112,101,110,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,32,116,111,32,109,97,110,97,103,101,32,97,110,32,101,120,105,115,116,105,110,103,32,115,117,98,115,99,114,105,112,116,105,111,110,46);
      buttonSizer.add(_0xd31108c6e0);

      _0xd31108c6e0.onClick = function ()
      {


         let _0x8ec282e798 = _0x18533ed6ec();
         if (_0x13cd1b694d() && _0xb860392b3d(_0x8ec282e798) &&
             _0x09d1497757(_0x8ec282e798) && !_0xae2bfdb8ee(_0x8ec282e798[String.fromCharCode(101,120,112,105,114,121)]))
         {
            let accountUrl = String.fromCharCode(104,116,116,112,115,58,47,47,119,119,119,46,116,101,111,114,105,97,100,101,108,99,111,108,111,114,46,101,115,47,97,99,99,111,117,110,116,47,109,121,45,115,117,98,115,99,114,105,112,116,105,111,110,115);
            if (_0x2f3ce02b79(accountUrl, "InNova profile") === false)
               new MessageBox("Your InNova profile could not be opened.\n\n" + accountUrl,
                  "InNova Integrator", StdIcon_Warning, StdButton_Ok).execute();
            return;
         }
         let _0x347c500185 = _0x3472346d4e(self[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text);

         if (_0x347c500185 === "")
         {
            new MessageBox(
               String.fromCharCode(65,32,118,97,108,105,100,32,77,97,99,104,105,110,101,32,73,68,32,105,115,32,114,101,113,117,105,114,101,100,32,98,101,102,111,114,101,32,112,117,114,99,104,97,115,105,110,103,32,97,32,115,117,98,115,99,114,105,112,116,105,111,110,46),
               "InNova Integrator",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
            return;
         }

         let planDialog = new _0x20b86eba4d;
         if (!planDialog.execute())
            return;

         if (planDialog.recoverExisting || planDialog.supportRecovery)
         {
            try
            {
               let recovery = RequestInNovaFirstActivation(_0x347c500185, true);
               self.accountLinkEdit.text = SoftwareLinkCode();
               firstPurchaseControlsRequested = true;
               UpdatePurchaseActivationControls();
               if (recovery === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68))
                  _0x2ab8232aec("InNova Integrator",
                     planDialog.supportRecovery ?
                        "Recover this computer with the one-time code supplied by InNova Support." :
                        "Authorize this computer with the account used for your purchase.",
                     planDialog.supportRecovery ? { supportRecovery: true } : { [String.fromCharCode(108,105,99,101,110,115,101,84,114,97,110,115,102,101,114)]: true });
               else
                  throw new Error("Recovery status: " + recovery);
            }
            catch (error)
            {
               if (error.innovaServerUnavailable) return;
               new MessageBox(String.fromCharCode(84,104,101,32,108,105,99,101,110,115,101,32,114,101,99,111,118,101,114,121,32,114,101,113,117,101,115,116,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,114,101,97,116,101,100,46,10,10) +
                  String(error.message || error), "InNova Integrator",
                  StdIcon_Warning, StdButton_Ok).execute();
            }
            return;
         }

         if (planDialog.selectedUrl === "")
            return;

         try
         {
            _0x347c500185 = _0x93ab2b0412(_0x347c500185);
            self[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text = _0x347c500185;
            PrepareInNovaFirstPurchase(_0x347c500185);
         }
         catch (error)
         {
            if (error.innovaServerUnavailable) return;
            let purchaseError = String(error.message || error);
            if (purchaseError === "PURCHASE_ACTIVATION_REQUIRED")
            {
               firstPurchaseControlsRequested = true;
               UpdatePurchaseActivationControls();
               new MessageBox(
                  String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,105,115,32,77,97,99,104,105,110,101,32,73,68,32,105,115,32,97,108,114,101,97,100,121,32,97,115,115,111,99,105,97,116,101,100,32,119,105,116,104,32,97,32,112,117,114,99,104,97,115,101,46,60,98,114,47,62,60,98,114,47,62) +
                  String.fromCharCode(60,98,62,89,111,117,114,32,77,97,99,104,105,110,101,32,73,68,32,104,97,115,32,98,101,101,110,32,107,101,112,116,32,117,110,99,104,97,110,103,101,100,46,60,47,98,62,60,98,114,47,62,60,98,114,47,62) +
                  "If you have already paid, click <b>Activate Purchase</b> and sign in<br/>" +
                  "with the account used for your purchase. Do not purchase again.<br/><br/>" +
                  "If this is not your purchase, contact InNova support.</p>",
                  "InNova Integrator", StdIcon_Information, StdButton_Ok).execute();
               return;
            }
            if (purchaseError.indexOf(String.fromCharCode(65,67,84,73,86,69,95,83,85,66,83,67,82,73,80,84,73,79,78,58)) === 0)
            {
               firstPurchaseControlsRequested = true;
               UpdatePurchaseActivationControls();
               let _0x443a2549ed = purchaseError.substring(
                  String(String.fromCharCode(65,67,84,73,86,69,95,83,85,66,83,67,82,73,80,84,73,79,78,58)).length);
               let _0xbccf7ea92c = _0x443a2549ed !== "" ?
                  String.fromCharCode(10,10,69,120,112,105,114,121,32,40,121,121,121,121,47,109,109,47,100,100,41,58,32) + [String.fromCharCode(97,99,116,105,118,101,69,120,112,105,114,121)] : "";
               new MessageBox(
                  String.fromCharCode(89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,105,115,32,97,108,114,101,97,100,121,32,97,99,116,105,118,101,46) + _0xbccf7ea92c +
                  String.fromCharCode(10,10,85,115,101,32,65,99,116,105,118,97,116,101,32,80,117,114,99,104,97,115,101,32,116,111,32,97,117,116,104,111,114,105,122,101,32,116,104,105,115,32,99,111,109,112,117,116,101,114,32,97,110,100,32,100,111,119,110,108,111,97,100,32,121,111,117,114,32,108,105,99,101,110,115,101,46,32,68,111,32,110,111,116,32,112,117,114,99,104,97,115,101,32,97,103,97,105,110,46),
                  "InNova Integrator",
                  StdIcon_Information,
                  StdButton_Ok
               ).execute();
               return;
            }
            new MessageBox(
               String.fromCharCode(84,104,101,32,77,97,99,104,105,110,101,32,73,68,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,98,101,102,111,114,101,32,112,117,114,99,104,97,115,101,46,10,10) +
               purchaseError + "\n\n" +
               "Check your Internet connection and try again.",
               "InNova Integrator",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
            return;
         }


         if (!CopyTextToSystemClipboard(_0x347c500185))
         {
            new MessageBox(
               String.fromCharCode(84,104,101,32,77,97,99,104,105,110,101,32,73,68,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,111,112,105,101,100,46,10,10) +
               "Select it manually and press Cmd+C or Ctrl+C.",
               "InNova Integrator",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
            return;
         }

         SetPurchaseStepPending(true);
         let pageOpened = false;
         try {
         new MessageBox(
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,77,97,99,104,105,110,101,32,73,68,32,99,111,112,105,101,100,32,116,111,32,116,104,101,32,99,108,105,112,98,111,97,114,100,46,60,47,112,62) +
            "<p align=\"center\">" +
            String.fromCharCode(84,104,101,32,115,117,98,115,99,114,105,112,116,105,111,110,32,99,104,101,99,107,111,117,116,32,112,97,103,101,32,119,105,108,108,32,110,111,119,32,111,112,101,110,46,60,47,112,62) +
            "<p align=\"center\"><b>" +
            String.fromCharCode(80,97,115,116,101,32,116,104,101,32,77,97,99,104,105,110,101,32,73,68,32,105,110,116,111,32,116,104,101,32,112,117,114,99,104,97,115,101,32,102,111,114,109,32,119,105,116,104,32,67,109,100,43,86,32,111,114,32,67,116,114,108,43,86,46) +
            "</b></p>",
            "InNova Integrator",
            StdIcon_Information,
            StdButton_Ok
         ).execute();

         console.noteln(String.fromCharCode(9989,32,77,97,99,104,105,110,101,32,73,68,32,99,111,112,105,101,100,32,116,111,32,116,104,101,32,99,108,105,112,98,111,97,114,100,46));

         let _0xf79ac38256 = planDialog.selectedUrl;
         pageOpened = _0x2f3ce02b79(_0xf79ac38256);
         if (pageOpened === false)
         {
            new MessageBox(
               String.fromCharCode(84,104,101,32,115,117,98,115,99,114,105,112,116,105,111,110,32,112,97,103,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,111,112,101,110,101,100,46,10,10) +
               _0xf79ac38256,
               "InNova Integrator",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
         }
         else if (pageOpened === true) {


            firstPurchaseControlsRequested = true;
            UpdatePurchaseActivationControls();


            ShowInNovaPurchaseReminderDialog();
         }
         } finally {


            if (pageOpened !== true) SetPurchaseStepPending(false);
         }
      };
      this[String.fromCharCode(111,112,101,110,83,117,98,115,99,114,105,112,116,105,111,110,80,108,97,110,115)] = _0xd31108c6e0.onClick;

      let _0xc1b9439e9e = new PushButton(this);
      _0xc1b9439e9e.text = String.fromCharCode(67,104,101,99,107,32,76,105,99,101,110,115,101,32,83,116,97,116,117,115);
      _0xc1b9439e9e.icon = this.scaledResource( ":/icons/ok.png" );
      _0xc1b9439e9e.setFixedWidth(190);
      _0xc1b9439e9e.setFixedHeight(WindowsOsx1 + 5);
      _0xc1b9439e9e.toolTip = String.fromCharCode(82,101,97,100,32,116,104,101,32,115,116,97,116,117,115,32,102,114,111,109,32,87,105,120,46,32,68,111,101,115,32,110,111,116,32,114,101,110,101,119,32,111,114,32,97,99,116,105,118,97,116,101,32,116,104,101,32,108,105,99,101,110,115,101,46);
      buttonSizer.add(_0xc1b9439e9e);
      _0xc1b9439e9e.onClick = function ()
      {
         try {
            let _0x452fea5cb7 = _0x18533ed6ec();
            if (!_0xb860392b3d(_0x452fea5cb7) || !_0x09d1497757(_0x452fea5cb7)) {
               if (!_0xb860392b3d(_0x452fea5cb7) && _0x7fbd7dc1d0 === "PROJECT" && IsProjectDateValid()) {
                  _0x26be79165f(_0x6a11780796());
                  return;
               }
               console.writeln(String.fromCharCode(78,111,32,118,97,108,105,100,32,115,97,118,101,100,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,97,118,97,105,108,97,98,108,101,46,32,89,111,117,114,32,116,114,105,97,108,32,115,116,97,116,117,115,32,105,115,32,117,110,99,104,97,110,103,101,100,46));
               new MessageBox(
                  String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,78,111,32,118,97,108,105,100,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,115,97,118,101,100,32,111,110,32,116,104,105,115,32,99,111,109,112,117,116,101,114,46,60,98,114,47,62,60,98,114,47,62) +
                  String.fromCharCode(89,111,117,114,32,116,114,105,97,108,32,115,116,97,116,117,115,32,105,115,32,117,110,99,104,97,110,103,101,100,46,60,98,114,47,62,60,98,114,47,62) +
                  String.fromCharCode(84,104,105,115,32,99,104,101,99,107,32,100,111,101,115,32,110,111,116,32,112,117,114,99,104,97,115,101,32,111,114,32,97,99,116,105,118,97,116,101,32,97,32,108,105,99,101,110,115,101,46,60,47,112,62),
                  "InNova Integrator", 0, StdButton_Ok
               ).execute();
               return;
            }
            let statusText = _0x251a597df6();
            console.writeln(statusText);
            let centeredStatus = "<p align=\"center\">" + statusText
               .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
               .replace(new RegExp(String.fromCharCode(94,40,83,117,98,115,99,114,105,112,116,105,111,110,32,115,116,97,116,117,115,32,92,40,87,105,120,92,41,58,32,41,40,65,67,84,73,86,69,124,71,82,65,67,69,124,69,88,80,73,82,69,68,124,82,69,86,79,75,69,68,41,36), "m"), "$1<b>$2</b>")
               .replace(new RegExp(String.fromCharCode(94,40,69,120,112,105,114,121,32,92,40,121,121,121,121,92,47,109,109,92,47,100,100,92,41,58,32,41,40,92,100,123,52,125,45,92,100,123,50,125,45,92,100,123,50,125,41,36), "m"), "$1<b>$2</b>")
               .replace(/^(✅ Installation authorized for this period: )(YES)$/m, "$1<b>$2</b>")
               .replace(/^(Installation authorized for this period: )(NO)$/m, "$1<b>$2</b>")
               .replace(new RegExp(String.fromCharCode(94,89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,104,97,115,32,98,101,101,110,32,99,97,110,99,101,108,108,101,100,92,46,36), "m"),
                  String.fromCharCode(60,98,62,60,115,112,97,110,32,115,116,121,108,101,61,34,99,111,108,111,114,58,35,100,48,48,48,48,48,34,62,89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,104,97,115,32,98,101,101,110,32,99,97,110,99,101,108,108,101,100,46,60,47,115,112,97,110,62,60,47,98,62))
               .replace(/^(You can continue using InNova for \d+ more day\(s\), until )(\d{4}-\d{2}-\d{2})(\.)$/m,
                  "$1<b>$2</b>$3")
               .replace(/\n/g, "<br/>") + "</p>";


            new MessageBox(centeredStatus, "InNova Integrator", 0, StdButton_Ok).execute();
         } catch (error) {
            if (error.innovaServerUnavailable) return;
            new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,76,105,99,101,110,115,101,32,115,116,97,116,117,115,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,104,101,99,107,101,100,46,60,98,114,47,62,60,98,114,47,62) +
               String.fromCharCode(67,104,101,99,107,32,121,111,117,114,32,73,110,116,101,114,110,101,116,32,99,111,110,110,101,99,116,105,111,110,32,111,114,32,99,111,110,116,97,99,116,32,115,117,112,112,111,114,116,46,32,89,111,117,114,32,108,105,99,101,110,115,101,32,104,97,115,32,110,111,116,32,98,101,101,110,32,99,104,97,110,103,101,100,46,60,47,112,62),
               "InNova Integrator", StdIcon_Warning, StdButton_Ok).execute();
         }
      };

      let _0x76206c0517 = new PushButton(this);
      _0x76206c0517.text = String.fromCharCode(76,105,99,101,110,115,101,32,112,114,111,98,108,101,109,115,63);
      _0x76206c0517.icon = this.scaledResource( ":/icons/info.png" );
      _0x76206c0517.setFixedWidth(190);
      _0x76206c0517.setFixedHeight(WindowsOsx1 + 5);
      _0x76206c0517.toolTip =
         String.fromCharCode(69,109,97,105,108,32,73,110,78,111,118,97,32,115,117,112,112,111,114,116,32,97,98,111,117,116,32,97,32,108,105,99,101,110,115,101,32,112,114,111,98,108,101,109,46);
      buttonSizer.add(_0x76206c0517);

      let premiumSiteButton = new PushButton(this);
      premiumSiteButton.text = "Premium site";
      premiumSiteButton.icon = this.scaledResource( ":/icons/internet.png" );
      premiumSiteButton.setFixedWidth(190);
      premiumSiteButton.setFixedHeight(WindowsOsx1 + 5);
      premiumSiteButton.toolTip =
         "Open the InNova Premium site. Available with an active paid plan.";
      premiumSiteButton.enabled = false;
      buttonSizer.add(premiumSiteButton);
      buttonSizer.addStretch();

      _0x76206c0517.onClick = function ()
      {
         if (!_0x80c932676d())
            new MessageBox(
               "Your email application could not be opened.\n\n" +
               "Email: soporte@teoriadelcolor.net\n" +
               String.fromCharCode(83,117,98,106,101,99,116,58,32,73,110,78,111,118,97,32,65,115,116,114,111,32,45,32,76,105,99,101,110,115,101,32,80,114,111,98,108,101,109),
               "InNova Integrator",
               StdIcon_Warning,
               StdButton_Ok
            ).execute();
      };

      premiumSiteButton.onClick = function ()
      {
         let premiumUrl = "https://www.teoriadelcolor.es/innova-premium";
         if (_0x2f3ce02b79(premiumUrl, "InNova Premium") === false)
            new MessageBox(
               "The InNova Premium site could not be opened.\n\n" + premiumUrl,
               "InNova Integrator",
               StdIcon_Warning,
               StdButton_Ok
            ).execute();
      };

      _0x1063dbbebd.sizer.add(buttonSizer);
      _0x1063dbbebd.sizer.add(accountLinkControl);
      _0x1063dbbebd.sizer.add(profileNoteControl);
      _0x1063dbbebd.sizer.addSpacing(14);
      _0x1063dbbebd.adjustToContents();


      let _0x0645b4afb7 = new GroupBox(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)]);
      _0x0645b4afb7.title = String.fromCharCode(76,105,99,101,110,115,101,32,65,99,116,105,118,97,116,105,111,110);
      _0x0645b4afb7.sizer = new VerticalSizer;
      _0x0645b4afb7.sizer.margin = 6;
         _0x0645b4afb7.sizer.spacing = 4;


      let activationInfoLabel = new Label(this);
      activationInfoLabel.useRichText = true;

      function UpdatePurchaseActivationControls()
      {
         let paid = _0x13cd1b694d();
         let code = SoftwareLinkCode();
         let hasCode = /^[A-F0-9]{4}(?:-[A-F0-9]{4}){5}$/.test(code);
         let showCode = hasCode && (paid || firstPurchaseControlsRequested);
         let showActivate = !paid && firstPurchaseControlsRequested;
         let layoutChanged = accountLinkControl.visible !== (showCode || showActivate) ||
            linkLabel.visible !== showCode || activatePurchaseButton.visible !== showActivate ||
            profileNoteControl.visible !== paid;
         self.accountLinkEdit.text = hasCode ? code : "";
         linkLabel.visible = showCode;
         self.accountLinkEdit.visible = showCode;
         activatePurchaseButton.visible = showActivate;
         accountLinkControl.visible = showCode || showActivate;
         profileNoteControl.visible = paid;


         if (layoutChanged && self.sizer)
         {
            _0x1063dbbebd.adjustToContents();
            self[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].adjustToContents();
            self.tabBox.adjustToContents();
            self.adjustToContents();
         }
      }

      function _0x1edc0a1ae1()
      {


         UpdatePurchaseActivationControls();
         let _0x8da2210445 = "NOT ACTIVATED";
         let remainingTimeText = "";

         if (_0x7fbd7dc1d0 === "PROJECT")
         {
            _0x8da2210445 = String.fromCharCode(84,82,73,65,76);
            remainingTimeText =
               String.fromCharCode(84,114,105,97,108,32,100,97,121,115,32,108,101,102,116,58,32) + _0x6a11780796() + "<br>";
         }
         else if (_0x7fbd7dc1d0 === "FULL" || _0x7fbd7dc1d0 === "FULL_GRACE")
         {
            _0x8da2210445 = _0x7fbd7dc1d0 === "FULL_GRACE" ?
               [String.fromCharCode(76,73,67,69,78,83,69,68,32,40,52,56,45,72,79,85,82,32,71,82,65,67,69,41)] : String.fromCharCode(76,73,67,69,78,83,69,68);

            let _0xfb7aa0d6f0 = _0x18533ed6ec();
            if (_0xb860392b3d(_0xfb7aa0d6f0))
            {
               remainingTimeText =
                  "Days until renewal: " +
                  _0x1b8f197376(_0xfb7aa0d6f0[String.fromCharCode(101,120,112,105,114,121)]) + "<br>" +
                  "Renewal date (yyyy/mm/dd): " +
                  String(_0xfb7aa0d6f0[String.fromCharCode(101,120,112,105,114,121)]).replace(/-/g, "/") + "<br>";
            }
         }


         let _0x03f77ea5a0 = _0x18533ed6ec();
         premiumSiteButton.enabled = _0x7fbd7dc1d0 === "FULL" &&
            _0xe807574588 &&
            _0xb860392b3d(_0x03f77ea5a0) &&
            _0x09d1497757(_0x03f77ea5a0) &&
            !_0xae2bfdb8ee(_0x03f77ea5a0[String.fromCharCode(101,120,112,105,114,121)]) &&
            _0x22aaae6f95(_0x03f77ea5a0);

         activationInfoLabel.text =
            "" + ProjecTname + " " + ProjecTver + "<br>" +
            "🪐 InNova Editor v.1.0.build." + INNOVA_EDITOR_BUILD + "<br>" +
            "💫 InNova Adaptive Stretch v.1.0.build." +
               InNovaAdaptiveStretchBuild + "<br>" +
            String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,109,111,100,101,58,32) + _0x8da2210445 + "</b><br>" +
            remainingTimeText +
            "Written by Jesús Manuel García Flores<br>" +
            "<a href=\"https://www.teoriadelcolor.es/innovaastrophotosuite\">www.teoriadelcolor.es/innovaastrophotosuite</a>";
      }

      _0x1edc0a1ae1();
      activationInfoLabel.textAlignment = TextAlign_Center;
      _0x0645b4afb7.sizer.add(activationInfoLabel);

      let informationGroupBox = new GroupBox(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)]);
      informationGroupBox.title = "Information";
      informationGroupBox.sizer = new VerticalSizer;
      informationGroupBox.sizer.margin = 6;
      informationGroupBox.sizer.spacing = 4;

      let thirdPartyInformationText =
         "Third-party software required for the script to work:\n\n" +
         "Remove Stars:\n" +
         "- StarNet free - Repository: https://pixinsight.starnetastro.com/\n" +
         "- StarXTerminator - www.rc-astro.com - Optional\n" +
         "* One of them must be installed\n\n" +
         "Noise Reduction:\n" +
         "- DeepSNR free - Repository: https://pixinsight.deepsnrastro.com/\n" +
         "- MLDenoise free with MLDenoise_v5.xmlm\n" +
         "- NoiseXTerminator - www.rc-astro.com - Optional\n" +
         "* One of them must be installed\n\n" +
         "Gradient Correction:\n" +
         "- Multiscale Gradient Correction requires MARS and Gaia DR3/SP databases.\n" +
         "- Store MARS and MLDenoise_v5.xmlm in Documents/InNova/data.";

      let informationLogoBitmap = null;
      try {
         let informationLogoPath = File.extractDrive(#__FILE__) +
            File.extractDirectory(#__FILE__) +
            "/InNova-Astro_Photo_Suite_logo.jpg";
         if (File.exists(informationLogoPath))
            informationLogoBitmap = new Bitmap(informationLogoPath);
      }
      catch (informationLogoError) {
         informationLogoBitmap = null;
      }

      let informationLogoControl = null;
      if (informationLogoBitmap && !informationLogoBitmap.isNull) {
         informationLogoControl = new Control(this);
         informationLogoControl.bitmap = informationLogoBitmap;
         informationLogoControl.setScaledFixedSize(160, 120);
         informationLogoControl.onPaint = function() {
            let graphics = new Graphics(this);
            graphics.drawScaledBitmap(
               new Rect(0, 0, this.width, this.height), this.bitmap);
            graphics.end();
         };

         let informationLogoRow = new HorizontalSizer;
         informationLogoRow.addStretch();
         informationLogoRow.add(informationLogoControl);
         informationLogoRow.addStretch();
         informationGroupBox.sizer.add(informationLogoRow);
         informationGroupBox.sizer.addSpacing(8);
      }

      let moreInformationButton = new PushButton(this);
      moreInformationButton.text = "More Information";
      moreInformationButton.icon = this.scaledResource(":/icons/info.png");
      moreInformationButton.onClick = function() {
         new MessageBox(
            thirdPartyInformationText,
            "InNova Integrator - More Information",
            StdIcon_Information,
            StdButton_Ok
         ).execute();
      };

      let moreInformationRow = new HorizontalSizer;
      moreInformationRow.addStretch();
      moreInformationRow.add(moreInformationButton);
      moreInformationRow.addStretch();
      informationGroupBox.sizer.add(moreInformationRow);


      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.add(_0x1063dbbebd);
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.add(_0x0645b4afb7);
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.add(informationGroupBox);

      _0x1063dbbebd.adjustToContents();
      _0x0645b4afb7.adjustToContents();
      informationGroupBox.adjustToContents();

      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].adjustToContents();


this.tabBox.addPage(this.integrationPage, "Integration");
this.tabBox.addPage(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)], String.fromCharCode(76,105,99,101,110,115,101));


      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;
      CropprojectTypeSizer.spacing = 10;
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);


      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;
      projectTypeSizer.spacing = 10;
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;
      alignmentSizer.spacing = 10;


      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;
      projectAndAlignmentSizer.spacing = 10;
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);


      this.integrationPage.sizer.add(projectAndAlignmentSizer);


      this.integrationPage.sizer.add(this.taggingGroupBox);


      this.integrationPage.sizer.add(this.optionsGroupsSizer);


      this.runButton = new PushButton(this);
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource(":/icons/play.png");
      this.runButton.toolTip = "Select Project type\nSelect Gradient Correction\nSelect images\nSelect Integration options\nand click on Run";
      this.runButton.setFixedWidth(102);
      this.runButton.setFixedHeight(WindowsOsx1);


      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";
      this.workingLabel.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;
      this.workingLabel.setFixedHeight(WindowsOsx1);

      this.workingStatusText = "";
      this.elapsedStartTime = 0;
      this.elapsedTimer = new Timer(1, true, this);

      this.formatElapsedTime = function (elapsedMilliseconds) {
         let totalSeconds = Math.max(0, Math.floor(elapsedMilliseconds/1000));
         let hours = Math.floor(totalSeconds/3600);
         let minutes = Math.floor((totalSeconds % 3600)/60);
         let seconds = totalSeconds % 60;

         function twoDigits(value) {
            return value < 10 ? "0" + value : "" + value;
         }

         return twoDigits(hours) + ":" + twoDigits(minutes) + ":" +
            twoDigits(seconds);
      };

      this.refreshWorkingLabel = function () {
         if (this.elapsedStartTime <= 0)
            return;

         this.workingLabel.text = this.workingStatusText +
            "  ⏱ Elapsed: " +
            this.formatElapsedTime(Date.now() - this.elapsedStartTime);
         this.workingLabel.update();
      };

      this.setWorkingStatus = function (statusText) {
         if (InNovaRunActive)
            InNovaAbortCheckpoint();
         this.workingStatusText = statusText;
         this.refreshWorkingLabel();
      };

      this.startElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.elapsedStartTime = Date.now();
         this.refreshWorkingLabel();
         this.elapsedTimer.start();
      };

      this.stopElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.refreshWorkingLabel();
      };

      this.elapsedTimer.onTimeout = function () {
         self.refreshWorkingLabel();
      };

      this.setProcessingLock = function (locked) {
         let configurationEnabled = !locked;


         this.projectTypeGroupBox.enabled = configurationEnabled;
         this.CropprojectTypeGroupBox.enabled = configurationEnabled;
         this.taggingGroupBox.enabled = configurationEnabled;
         this.optionsGroupBox.enabled = configurationEnabled;
         this.finalOptionsGroupBox.enabled = configurationEnabled;
         this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].enabled = configurationEnabled;

         if (locked) {
            this.runButton.enabled = false;
            this.Iconize3.enabled = false;
            this.Iconize6.enabled = false;
            this.exitButton.text = "STOP";
            this.exitButton.icon =
               this.scaledResource( ":/icons/cancel.png" );
            this.exitButton.toolTip =
               "Stop the current project safely and delete its temporary results";
            this.exitButton.enabled = true;
         } else {
            this.runButton.enabled = CanProcess();
            this.Iconize3.enabled = true;
            this.Iconize6.enabled = true;
            this.exitButton.text = "Exit";
            this.exitButton.icon =
               this.scaledResource( ":/icons/close.png" );
            this.exitButton.toolTip = "Close InNova Integrator";
            this.exitButton.enabled = true;
         }

         this.update();
      };


      let horizontalSizer2 = new HorizontalSizer;
      horizontalSizer2.spacing = 5;
      horizontalSizer2.margin = 0;


      horizontalSizer2.add(this.workingLabel, 100);


      this.integrationPage.sizer.add(horizontalSizer2);


      this.Iconize3 = new PushButton(this);
      this.Iconize3.text = "Trash";
      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setFixedWidth(102);
      this.Iconize3.setFixedHeight(WindowsOsx1);
      this.Iconize3.toolTip = "Delete actual project";
      if (!CanProcess())
      {
         self.runButton.enabled = false;
      }
      else
      {
         self.runButton.enabled = true;
      }


      self.Iconize6 = new PushButton(this);
      self.Iconize6.text = "Settings";
      self.Iconize6.icon = this.scaledResource( ":/icons/process.png" );
      self.Iconize6.setFixedWidth(102);
      self.Iconize6.setFixedHeight(WindowsOsx1);
      self.Iconize6.toolTip = "Options and Settings";
      self.Iconize6.enabled = true;


      var self = this;

      this.runButton.onClick = function () {
      if (!CanProcess())
      {
         new MessageBox(
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,116,114,105,97,108,32,111,114,32,108,105,99,101,110,115,101,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
            String.fromCharCode(80,108,101,97,115,101,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32,60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32) +
            String.fromCharCode(116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
            "InNova Integrator",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }


     let selectedProjectTypes = [
        "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC"
     ];
     let selectedProjectType = selectedProjectTypes[self.projectTypeComboBox.currentItem];
     OptionObjectType = self.objectTypeComboBox.currentItem === 1 ?
        "MOON_SUN" : "STARS";
     OptionSeestar = self.projectTypeComboBox.currentItem === 5 ? "ON" : "OFF";
     OptionVaonisVespera =
        (self.projectTypeComboBox.currentItem === 5 ||
         self.projectTypeComboBox.currentItem === 6) ? "ON" : "OFF";

     if (OptionVaonisVespera === "ON" && OptionObjectType === "STARS") {
        self.ImageSolverCheckBox.checked = true;
        self.ImageSolverCheckBox.enabled = false;
        OptionImageSolver = "ON";
     }

     ProjecTypevar = selectedProjectType;
     ProjecTypevarRec = selectedProjectType;


     OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
     OptionFast = self.FastCheckBox.enabled && self.FastCheckBox.checked ?
        "ON" : "OFF";
     OptionLinkRGB = self.linkRGBChannels.checked ? "true" : "false";


     OptionDarkStructureEnhance = "ON";
     OptionOpenInNovaEditor = "ON";
     OptionHavar = self.HalphaCheckBox.enabled &&
        self.HalphaCheckBox.checked ? "ON" : "OFF";
     Option300 = self.resolutionCheckBox.checked ? "ON" : "OFF";
     OptionGradient = self.gradientCorrectionComboBox.currentItem === 0 ?
        "ON" : "OFF";
     OptionMgc = self.gradientCorrectionComboBox.currentItem === 1 ?
        "ON" : "OFF";

     if (OptionVaonisVespera === "ON" && OptionObjectType === "STARS")
        OptionImageSolver = "ON";


     OptionGraXNoise = "OFF";
     OptionMLDenoise = "OFF";
     OptionNoiseXterminator = "OFF";
     OptionBlurXterminator = "OFF";
     OptionHighpass = "OFF";
     OptionVarStars = self.starlessMethodComboBox.currentItem > 0 ? "ON" : "OFF";
     OptionStarXterminator = self.starlessMethodComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionFinalStarRefinement =
        OptionVarStars === "ON" ? "ON" : "OFF";
     FinalStarRefinementReady = false;


     if (OptionVarStars === "ON" && self.finalStarsComboBox.currentItem === 0)
        self.finalStarsComboBox.currentItem = 1;
     OptionHSOvar = self.finalStarsComboBox.currentItem === 1 ? "ON" : "OFF";
     Option1var = self.finalStarsComboBox.currentItem === 2 ? "ON" : "OFF";
     ProjecTypevar2 = Option1var === "ON" ? "1" : "0";


     if (OptionObjectType === "MOON_SUN") {
        if (selectedProjectType !== "OSC") {
           new MessageBox(
              "Moon / Sun mode requires an OSC, SEESTAR or VAONIS Vespera " +
              "project with one selected image.",
              "InNova Integrator - Moon / Sun",
              StdIcon_Error,
              StdButton_Ok
           ).execute();
           return;
        }

        self.ImageSolverCheckBox.checked = false;
        self.ImageSolverCheckBox.enabled = false;
        self.gradientCorrectionComboBox.currentItem = 0;
        self.gradientCorrectionComboBox.enabled = false;
        self.starlessMethodComboBox.currentItem = 0;
        self.starlessMethodComboBox.enabled = false;
        self.finalStarsComboBox.currentItem = 0;
        self.finalStarsComboBox.enabled = false;
        self.HalphaCheckBox.checked = false;
        self.HalphaCheckBox.enabled = false;

        OptionImageSolver = "OFF";
        OptionGradient = "ON";
        OptionMgc = "OFF";
        OptionVarStars = "OFF";
        OptionStarXterminator = "OFF";
        OptionFinalStarRefinement = "OFF";
        OptionHSOvar = "OFF";
        Option1var = "OFF";
        OptionHavar = "OFF";
        ProjecTypevar2 = "0";

        console.noteln(
           "🌙 Moon / Sun project: ImageSolver, MGC, Final_starless " +
           "creation and final-star processing will be skipped.");
     }


     if (OptionFast === "ON" && Option1var === "ON") {
        console.warningln(
           "⚠️ FAST mode does not run the separate RGB star integration. " +
           "Using project stars for this run.");
        self.finalStarsComboBox.currentItem = 1;
        Option1var = "OFF";
        OptionHSOvar = "ON";
        ProjecTypevar2 = "0";
     }
     VarProcesStar = "OFF";
     VarPGlobal = "EMPTY";
     isStarProcess = false;
     OptionRemaind2 = null;
     OptionEnabledPreview2 = "OFF";
     InteractiveProcessStrengths.DeepSNR = null;
     InteractiveProcessStrengths.MLDenoise = null;
     InteractiveProcessStrengths.NoiseXTerminator = null;
     InteractiveProcessStrengths.BlurXTerminator = null;
     InteractiveProcessStrengths.HighPass = null;
     InteractiveProcessStrengths.NarrowbandToRGB = null;
     InteractiveProcessMaskModes.DeepSNR = "none";
     InteractiveProcessMaskModes.MLDenoise = "none";
     InteractiveProcessMaskModes.NoiseXTerminator = "none";
     InteractiveProcessMaskModes.BlurXTerminator = "none";
     InteractiveProcessMaskModes.HighPass = "none";
     InteractiveProcessMaskModes.NarrowbandToRGB = "none";
     InteractiveProcessMaskBanks.DeepSNR = null;
     InteractiveProcessMaskBanks.MLDenoise = null;
     InteractiveProcessMaskBanks.NoiseXTerminator = null;
     InteractiveProcessMaskBanks.BlurXTerminator = null;
     InteractiveProcessMaskBanks.HighPass = null;
     InteractiveProcessMaskBanks.NarrowbandToRGB = null;


     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {

            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {

            self.finalStarsComboBox.currentItem = 0;
            Option1var = "OFF";
            self.update();
            return;
        }
     }


      console.noteln("🟢" +" Initializing Script...");


      if (!MiraRestoreSelectedSourceIds()) {
         console.criticalln(
            "❌ Source-window identifiers are ambiguous. Close or rename the duplicate window reported above, then run the script again.");
         return;
      }


      if (!MiraCheckWindowsABE()) {
         console.warningln("\n⚠️ Run cancelled because previous intermediate windows are still open.");
         return;
      }

      let msgBox = new MessageBox("Do you want to Run the Script?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_Yes) {


        MiraPrepareWorkspaceForRun(dialog);

        FinalFocusWindowId = "";
        FinalConvertedFocusWindowId = "";
        let startTime = Date.now();
        dialog.workingStatusText = String.fromCharCode(83,116,97,114,116,105,110,103,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46);
        dialog.startElapsedTimer();
        let processCompleted = false;
        InNovaStopRequested = false;
        InNovaStopCleanupRequested = false;
        InNovaRunActive = true;
        dialog.setProcessingLock(true);

        try {

        MiraConsoleSection("🚀 Launching InNova Integrator project...");

        dialog.workingLabel.foregroundColor = 0x0000FF;
        dialog.workingLabel.update();


         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln(String.fromCharCode(10,10060,32,86,97,108,105,100,97,116,105,111,110,32,102,97,105,108,101,100,46,32,80,108,101,97,115,101,32,115,101,108,101,99,116,32,105,109,97,103,101,115,46));
          return;
        } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
        }


        if (OptionObjectType === "STARS" &&
            OptionImageSolver !== "ON" &&
            !MiraValidateSelectedImageAstrometry(ProjecTypevar)) {
           OptionImageSolver = "ON";
           self.ImageSolverCheckBox.checked = true;
           self.ImageSolverCheckBox.update();

           console.noteln(
              "🔭 Astrometric data are missing. ImageSolver has been enabled automatically."
           );

           new MessageBox(
              "InNova has detected that one or more selected images require an " +
              "astrometric solution.<br><br>" +
              "<b>ImageSolver will now run automatically.</b> You do not need to enable " +
              "the option or restart the process.<br><br>" +
              "InNova will continue the integration as soon as the astrometric " +
              "solution has been generated.",
              "InNova Integrator - Automatic ImageSolver",
              StdIcon_Information,
              StdButton_Ok
           ).execute();
        }


        if (OptionObjectType === "STARS" && OptionImageSolver === "ON") {
           dialog.setWorkingStatus(String.fromCharCode(82,117,110,110,105,110,103,32,73,109,97,103,101,83,111,108,118,101,114,32,111,110,32,115,101,108,101,99,116,101,100,32,105,109,97,103,101,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
           let imageSolverBaselineWindows = ImageWindow.windows.slice();
           if (!MiraRunImageSolverForSelectedImages(ProjecTypevar)) {
              MiraCleanupImageSolverAttempt(imageSolverBaselineWindows);

              let imageSolverCanContinue = OptionMgc !== "ON";
              let imageSolverDetail =
                 (typeof MiraImageSolverLastError === "string" &&
                  MiraImageSolverLastError.length > 0) ?
                    MiraImageSolverLastError :
                    "ImageSolver could not generate a valid astrometric solution.";
              imageSolverDetail = String(imageSolverDetail)
                 .replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;");
              let imageSolverMessage =
                 "ImageSolver could not solve the selected image.<br><br>" +
                 "If this is an image of the Moon or the Sun, restart InNova and, " +
                 "in the Object section, choose <b>Moon / Sun</b>.<br><br>";

              if (imageSolverCanContinue) {
                 imageSolverMessage +=
                    "The options currently enabled do not require astrometry, so " +
                    "InNova Integrator will continue without ImageSolver.<br><br>" +
                    "Details: " + imageSolverDetail;
                 new MessageBox(
                    imageSolverMessage,
                    "InNova Integrator - ImageSolver",
                    StdIcon_Warning,
                    StdButton_Ok
                 ).execute();
                 OptionImageSolver = "OFF";
                 self.ImageSolverCheckBox.checked = false;
                 self.ImageSolverCheckBox.update();
                 console.warningln(
                    "⚠️ ImageSolver failed, but no active process requires astrometry. Continuing safely without ImageSolver.");
              }
              else {
                 imageSolverMessage +=
                    "The active Multiscale Gradient Correction requires astrometry. " +
                    "InNova Integrator must stop.<br><br>" +
                    "All temporary ImageSolver results have been removed and the " +
                    "original selected image has been preserved.<br><br>" +
                    "Details: " + imageSolverDetail;
                 new MessageBox(
                    imageSolverMessage,
                    "InNova Integrator - ImageSolver",
                    StdIcon_Error,
                    StdButton_Ok
                 ).execute();
                 console.criticalln(
                    "\n❌ 🔭 ImageSolver failed. Astrometry is required by Multiscale Gradient Correction, so InNova Integrator stopped before processing.");
                 return;
              }
           }
        }

        dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
        if (!MiraProyecto())
            {
               console.criticalln("Process cancelled.");
               return;
            }


        if (OptionMgc ==="ON") {


           if (!MiraValidateMgcConfiguration(true)) {
              OptionMgc = "OFF";
              OptionGradient = "ON";
              dialog.gradientCorrectionComboBox.currentItem = 0;
           }
           else {
              MiraConsoleSection("Launching MARS databases...");
              dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,77,117,108,116,105,115,99,97,108,101,32,71,114,97,100,105,101,110,116,32,67,111,114,114,101,99,116,105,111,110,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
              console.noteln("Launching Multiscale Gradient Correction process...");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin1) + ": \n" + originalFilePathMarsfin1);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin2) + ": \n" + originalFilePathMarsfin2);


              if (!MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, MiraImageSolverSelectedIds(ProjecTypevar))) {
                 console.criticalln(
                    "❌ Multiscale Gradient Correction did not complete on every selected image. Processing has been stopped to avoid mixing corrected and uncorrected channels.");
                 return;
              }
           }
        }


        dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));

            if (MiraVentana()) {


            dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            MiraRenombre();
            if (OptionObjectType === "MOON_SUN" &&
                !MiraPrepareMoonSunOscColor()) {
               console.criticalln(
                  "❌ Moon / Sun colour preparation failed. Processing has been stopped safely.");
               return;
            }
            dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return;
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }


            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,53,47,57,46,32,77,97,105,110,32,112,114,111,99,101,115,115,44,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            MiraProcesoGeneral01();
            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,54,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            if (!MiraChannelCom()) {
               console.criticalln(
                  "❌ Channel combination or final-window creation failed. Processing has been stopped safely.");
               return;
            }

            if (!MiraValidateFinalWindowContract(
                   OptionFast === "ON" && OptionVarStars === "ON",
                   "Channel combination"))
               return;

            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,55,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


               let finalColorTarget = ImageWindow.windowById("Final_starless");
               if (finalColorTarget && !finalColorTarget.isNull)
                  finalColorTarget.bringToFront();
               MiraGreen();


            dialog.setWorkingStatus(
               "Adjusting background, denoise and sharpen on the visible final image...");
            if (!MiraApplyVisibleFinalProcesses())
               return;

            if (OptionVarStars === "ON") {
                console.noteln("\n✅ Creating Starless Final Image");

                if (Option1var === "ON") {
                        if (OptionFast === "OFF"){
                              console.noteln("\n" + "Launching RGB stars process.");
                              try {
                                 MiraRGBStars();
                              } finally {


                                 VarProcesStar = "OFF";
                                 ProjecTypevar = ProjecTypevarRec;
                              }
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                } else if (OptionHSOvar === "ON") {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars2();

                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars();

                              }
                        }
                }
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
            console.show();

            if (!MiraValidateFinalWindowContract(
                   OptionVarStars === "ON", "Final star creation"))
               return;


            if (OptionHavar ==="ON"){
               let imageWindow = "Filter_Ha_registered_ABE";
               if (!InNovaEditorRunHAlphaStage(
                     imageWindow, ProjecTypevarRec))
                  return;
            }

            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,57,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


            dialog.setWorkingStatus(
               String.fromCharCode(73,110,78,111,118,97,32,68,97,114,107,32,83,116,114,117,99,116,117,114,101,32,69,110,104,97,110,99,101,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            if (!InNovaEditorRunDarkStructuresStage(
                  ProjecTypevarRec))
               return;


            if (OptionVarStars === "ON") {
               dialog.setWorkingStatus(
                  String.fromCharCode(82,101,102,105,110,105,110,103,32,116,104,101,32,102,105,110,97,108,32,115,116,97,114,32,108,97,121,101,114,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
               if (!InNovaEditorRunStarRefinementStage(
                     ProjecTypevarRec))
                  return;
            }

              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break;
                         }
                   }
              }

            MiraRenProyectos();

            MiraResolFinal();
            InNovaAbortCheckpoint();
            MirashowTotalTime(startTime);
            Option2var2 = "ON";


            dialog.stopElapsedTimer();
            MiraBorraVentanas();

            MiraOrdena1();
            MiraFocusFinalOutput();
            InNovaAbortCheckpoint();


            if (OptionOpenInNovaEditor === "ON") {
               let finalId = FinalConvertedFocusWindowId ||
                             FinalFocusWindowId;
               if (!finalId || finalId.length === 0) {
                  let finalWindow = ImageWindow.activeWindow;
                  finalId = finalWindow && !finalWindow.isNull &&
                            finalWindow.mainView &&
                            !finalWindow.mainView.isNull ?
                            finalWindow.mainView.id : "";
               }
               let verifiedFinal = ImageWindow.windowById(finalId);
               if (verifiedFinal && !verifiedFinal.isNull &&
                   verifiedFinal.mainView &&
                   !verifiedFinal.mainView.isNull) {
                  InNovaEditorPendingSourceId = finalId;
                  InNovaEditorPendingProjectType = ProjecTypevarRec;
                  InNovaEditorPendingLaunch = true;
                  console.noteln(
                     "🪐 InNova Editor queued for: " + finalId);
               }
               else {
                  console.warningln(
                     "⚠️ 🪐 InNova Editor was not opened because no valid final image was found.");
               }
            }

            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            if (!InNovaEditorPendingLaunch)
               console.noteln("\n✅ End of project.");
            dialog.setWorkingStatus("✅ Process completed.");
            processCompleted = true;
            if (InNovaEditorPendingLaunch)
               dialog.ok();


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
        } catch (processingError) {
            console.show();
            let processingMessage = processingError && processingError.message ?
               processingError.message : processingError;
            if ((processingError && processingError.inNovaUserStop) ||
                InNovaStopRequested) {
               console.warningln(
                  "\n⛔ InNova Integrator stopped by the user at a safe checkpoint.");
            }
            else {
               console.criticalln(
                  "\n❌ 🔭 InNova Integrator stopped after an unexpected processing error: " +
                  processingMessage);
               if (processingError && processingError.stack)
                  console.criticalln(processingError.stack);
               new MessageBox(
                  "InNova Integrator stopped safely.\n\n" + processingMessage +
                  "\n\nReview the Process Console for the stage and missing window details.",
                  "InNova Integrator processing error",
                  StdIcon_Error,
                  StdButton_Ok
               ).execute();
            }
        } finally {


            try {
               MiraRestoreSelectedSourceIds();
            } catch (restoreError) {
               console.warningln(
                  "⚠️ Source-window names could not be fully restored: " +
                  restoreError.message);
            }
            VarProcesStar = "OFF";
            VarPGlobal = "EMPTY";
            isStarProcess = false;
            ProjecTypevar = ProjecTypevarRec;
            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            dialog.stopElapsedTimer();
            let stoppedByUser = InNovaStopRequested;


            InNovaRunActive = false;
            if (stoppedByUser && InNovaStopCleanupRequested) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  "⛔ Stopped. Cleaning project windows...";
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
               try {
                  MiraCheckWindowsTrash(true);
                  MiraOrdena1();
                  console.noteln(
                     "✅ STOP cleanup completed. Original source images were preserved.");
               }
               catch (cleanupError) {
                  console.criticalln(
                     "❌ STOP cleanup could not remove every project window: " +
                     (cleanupError.message || cleanupError));
               }
            }
            InNovaStopRequested = false;
            InNovaStopCleanupRequested = false;
            dialog.setProcessingLock(false);

            if (stoppedByUser) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  "⛔ Process stopped. Project workspace cleaned.";
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
            }
            else if (!processCompleted)
               dialog.setWorkingStatus("⚠️ Process stopped.");
        }
    } else {
        console.warningln("\nFinished script...");
    }
};


      this.Iconize3.onClick = function() {


               self.projectTypeComboBox.enabled = true;

          MiraCheckWindowsTrash();
          MiraOrdena1();


      };


self.Iconize6.onClick = function() {

   let mgcDialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2, SensorName);
   mgcDialog.adjustToContents();
   MiraCenterDialog(mgcDialog);
   mgcDialog.execute();
};


     this.exitButton = new PushButton(this);
     this.exitButton.text = "Exit";
     this.exitButton.icon = this.scaledResource( ":/icons/close.png" );
     this.exitButton.setFixedWidth(102);
     this.exitButton.setFixedHeight(WindowsOsx1);


     this.exitButton.onClick = function () {
        if (InNovaRunActive) {
           InNovaRequestStop("the main window");
           return;
        }
        this.dialog.cancel();
    };


      this.consoleButton = new PushButton(this);
      this.consoleButton.text = "Hide";
      this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
      this.consoleButton.setFixedWidth(102);
      this.consoleButton.setFixedHeight(WindowsOsx1);
      this.consoleButton.toolTip = "Show or hide the PixInsight Process Console";
      this.consoleButton.onClick = function () {
         if (OptionshowConsolRadio === "ON") {
            OptionshowConsolRadio = "OFF";
            this.text = "Show";
            console.hide();
         }
         else {
            OptionshowConsolRadio = "ON";
            this.text = "Hide";
            console.show();
         }
      };


    this.actionButtonsSizer = new HorizontalSizer;
    this.actionButtonsSizer.spacing = 10;
    this.actionButtonsSizer.addStretch();
    this.actionButtonsSizer.add(this.runButton);
    this.actionButtonsSizer.add(this.consoleButton);
    this.actionButtonsSizer.add(this.Iconize3);
    this.actionButtonsSizer.add(this.Iconize6);
    this.actionButtonsSizer.add(this.exitButton);
    this.actionButtonsSizer.addStretch();


    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;


    this.sizer.add(this.tabBox, 100);
    this.sizer.addSpacing(10);
    this.sizer.add(this.actionButtonsSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = ProjecTname;


}
}


let dialog = new IntegratorDialog();
InNovaProjectSelectionLoggingEnabled = true;
UpdateInstalledAppsUI(dialog);


dialog.initialCenterTimer = new Timer;
dialog.initialCenterTimer.interval = 0.05;
dialog.initialCenterTimer.periodic = false;
dialog.initialCenterTimer.onTimeout = function ()
{
   MiraCenterDialog(dialog);
};
dialog.onShow = function ()
{
   MiraCenterDialog(this);
   dialog.initialCenterTimer.start();
};


dialog.actualizarComboBoxesDesdeGUI = function () {

   var self = dialog;


   let availableImageIds = [];
   let windows = ImageWindow.windows;

   for (let i = 0; i < windows.length; ++i) {
      if (!windows[i] || windows[i].isNull || !windows[i].mainView || windows[i].mainView.isNull)
         continue;

      let id = windows[i].mainView.id;
      if (
         id.indexOf("Final_") === 0 ||
         id.indexOf("Base_") === 0 ||


         id.indexOf("Image_") === 0 ||
         id.indexOf("Gray") === 0 ||
         id.indexOf("_registered") !== -1 ||
         id.indexOf("_ABE") !== -1 ||
         id.indexOf("_stars") !== -1
      )
         continue;

      availableImageIds.push(id);
   }

   function actualizarCombo(comboBox) {
      if (!comboBox)
         return;

      comboBox.clear();
      comboBox.addItem("<Select an Image>");

      for (let i = 0; i < availableImageIds.length; ++i)
         comboBox.addItem(availableImageIds[i]);

      comboBox.currentItem = 0;
   }

   for (let key in self.comboBoxReferences) {
      actualizarCombo(self.comboBoxReferences[key]);
   }

   PimageSii = "EMPTY";
   PimageHa = "EMPTY";
   PimageOiii = "EMPTY";
   PimageRed = "EMPTY";
   PimageGreen = "EMPTY";
   PimageBlue = "EMPTY";
   PimageLuminance = "EMPTY";
   PimageOsc = "EMPTY";

   CoreApplication.processEvents();
   self.update();
};


if (CanStartApp)
{
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   if (_0xd5ac9036f9 &&
       typeof dialog[String.fromCharCode(111,112,101,110,83,117,98,115,99,114,105,112,116,105,111,110,80,108,97,110,115)] === "function")
   {
      _0xd5ac9036f9 = false;
      dialog[String.fromCharCode(111,112,101,110,83,117,98,115,99,114,105,112,116,105,111,110,80,108,97,110,115)]();
   }
   dialog.execute();

   if (InNovaEditorPendingLaunch) {
      InNovaIntegratorOpenInNovaEditor(
         InNovaEditorPendingSourceId,
         InNovaEditorPendingProjectType);
      console.noteln("\n✅ End of project.");
   }
}
else
{
   console.criticalln("Application startup blocked.");
}

#endif
