#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaEditor : InNova Astro Photo Suite > InNova Editor
#feature-icon  InNovaIcon.svg
#feature-info  Final image editor for InNova Astro Photo Suite. \
Uses the shared InNova Astro Photo Suite access state. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#define TITLE "InNova Editor"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>


var ProjecTname = "🪐 InNova Editor";
var ProjecTver = "v.1.0.build.0146";
var _0x62abc0e7dd = String.fromCharCode(51,49,97,100,48,56,120,106,114);
var _0x24a79c05f1 =
   String.fromCharCode(53,52,48,48,54,54,98,101,97,97,50,97,49,56,100,98,51,100,55,101,99,97,55,54,55,99,49,55,52,50,52,52,50,57,49,97,53,100,100,53,48,55,99,53,98,50,55,99,50,55,101,56,100,101,97,48,50,57,102,56,102,50,51,52);
var _0x2ec0322bf9 = "";
var _0x7fbd7dc1d0 = "EMPTY";
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);


var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionNarrowbandToRGB = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";
var Option300 = "OFF";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var StarXPath = "EMPTY";
var StarXPath0 = "StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 = "StarXTerminator.lite.nonoise.11.pb";
var StarBPath = "EMPTY";
var StarBPath0 = "BlurXTerminator.4.mlpackage";
var StarBPath1 = "BlurXTerminator.4.pb";
var StarNPath = "EMPTY";
var StarNPath0 = "NoiseXTerminator.2.mlpackage";
var StarNPath03 = "NoiseXTerminator.3.mlpackage";
var StarNPath1 = "NoiseXTerminator.2.pb";
var StarNPath13 = "NoiseXTerminator.3.pb";
var StarMarsFirst = "MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond = "MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel = "MLDenoise_v5.xmlm";
var originalFilePathMLDenoisefin = "";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};
var InNovaEditorTitle = "🪐 InNova Editor";

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"

function _0x5bd1131af4()
{
   if (!_0xe1a1c5d578()) {
      _0x2ec0322bf9 = "";
      _0x7fbd7dc1d0 = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   CompletePendingInNovaPurchase();
   let _0x6e002bc706 = _0xf9d6c7e58d();
   let complete = _0xb860392b3d(_0x6e002bc706);
   let signatureValid = complete && _0x09d1497757(_0x6e002bc706);
   let _0x8c886c9d4f = signatureValid && _0xae2bfdb8ee(_0x6e002bc706[String.fromCharCode(101,120,112,105,114,121)]);

   let refreshOutcome = {};
   if (signatureValid && _0x6dbb58fa29(_0x6e002bc706, _0x8c886c9d4f, refreshOutcome)) {
      _0x6e002bc706 = _0x18533ed6ec();
      complete = _0xb860392b3d(_0x6e002bc706);
      signatureValid = complete && _0x09d1497757(_0x6e002bc706);
      _0x8c886c9d4f = signatureValid && _0xae2bfdb8ee(_0x6e002bc706[String.fromCharCode(101,120,112,105,114,121)]);
   }

   if (signatureValid) _0x475d0d9c24();
   let _0xeac19aaf78 = _0x13cd1b694d();
   _0x8c886c9d4f = signatureValid && _0xae2bfdb8ee(_0x6e002bc706[String.fromCharCode(101,120,112,105,114,121)]);
   let grace = signatureValid && _0x8c886c9d4f && _0xe807574588 &&
      typeof InNovaSoftwareState !== "undefined" && InNovaSoftwareState &&
      InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)] && InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)].status === "GRACE" &&
      _0xfa5bc089aa(_0x6e002bc706[String.fromCharCode(101,120,112,105,114,121)]);

   if (signatureValid && refreshOutcome.status === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
       refreshOutcome.paidRenewalPending && !_0xe807574588) {
      _0x2ec0322bf9 = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
      _0x7fbd7dc1d0 = "DEVICE_REQUIRED";
      ShowInNovaPaidRenewalNotice("InNova Editor");
      return false;
   }

   if (signatureValid && _0xe807574588 && (!_0x8c886c9d4f || grace)) {
      _0x2ec0322bf9 = _0x6e002bc706[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
      _0x7fbd7dc1d0 = grace ? "FULL_GRACE" : "FULL";
      if (grace)
         _0xa3650bb7b1("InNova Editor", _0x6e002bc706, true);
      else
         console.noteln(String.fromCharCode(9989,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,108,105,99,101,110,115,101,32,97,99,116,105,118,97,116,101,100,46));
      return true;
   }

   if (!complete && !_0xeac19aaf78 && IsProjectDateValid()) {
      _0x2ec0322bf9 = _0x8ef1ec869a().substr(0, 8);
      _0x7fbd7dc1d0 = "PROJECT";
      console.noteln(String.fromCharCode(55358,56810,32,76,105,99,101,110,115,101,32,109,111,100,101,58,32,84,82,73,65,76));
      console.noteln(String.fromCharCode(55357,56517,32,84,114,105,97,108,32,116,105,109,101,32,114,101,109,97,105,110,105,110,103,58,32) + _0x6a11780796() + " day(s).");
      return true;
   }

   _0x2ec0322bf9 = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
   if (_0x8c886c9d4f && !grace) {
      _0x7fbd7dc1d0 = String.fromCharCode(69,88,80,73,82,69,68);
      _0xa3650bb7b1("InNova Editor", _0x6e002bc706, false);
      return false;
   }
   if (signatureValid && !_0xe807574588) {
      _0x7fbd7dc1d0 = "DEVICE_REQUIRED";
      _0x2ab8232aec("InNova Editor",
         String.fromCharCode(84,104,105,115,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,111,110,32,116,104,105,115,32,100,101,118,105,99,101,46));
      return false;
   }
   _0x7fbd7dc1d0 = "EMPTY";
   if (_0xeac19aaf78 || complete) {
      _0x2ab8232aec("InNova Editor",
         String.fromCharCode(89,111,117,114,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,109,105,115,115,105,110,103,32,111,114,32,105,110,118,97,108,105,100,46,32,80,108,101,97,115,101,32,114,101,115,116,111,114,101,32,121,111,117,114,32,108,105,99,101,110,115,101,32,102,114,111,109,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,46),
         { [String.fromCharCode(109,105,115,115,105,110,103,76,105,99,101,110,115,101)]: true });
      return false;
   }
   new MessageBox(
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,101,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,116,114,105,97,108,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
         String.fromCharCode(80,108,101,97,115,101,32,111,112,101,110,32,73,110,78,111,118,97,32,73,110,116,101,103,114,97,116,111,114,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32) +
         String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32,116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
      "InNova Editor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaEditorResetEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaEditorCloneWindow(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      sourceWindow.isColor !== undefined ? sourceWindow.isColor : true,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      output.keywords = sourceWindow.keywords;
   }
   catch (e) {
   }

   return output;
}

function InNovaEditorInferProjectType(windowId)
{
   let upperId = windowId.toUpperCase();
   if (upperId.indexOf("SHO") !== -1)
      return "SHO";
   if (upperId.indexOf("HOO") !== -1)
      return "HOO";
   if (upperId.indexOf("LRGB") !== -1)
      return "LRGB";
   if (upperId.indexOf("OSC") !== -1 ||
       upperId.indexOf("VAONIS") !== -1 ||
       upperId.indexOf("SEESTAR") !== -1)
      return "OSC";
   return "RGB";
}

class InNovaEditorDialog extends Dialog
{
   constructor()
   {
      super();
      let dialog = this;
      this.windowTitle = "🪐 InNova Editor";

      let logoPath = "";
      this.logoBitmap = null;
      try {
         logoPath = File.extractDrive(#__FILE__) +
            File.extractDirectory(#__FILE__) +
            "/InNova-Astro_Photo_Suite_logo.jpg";
         if (File.exists(logoPath))
            this.logoBitmap = new Bitmap(logoPath);
      }
      catch (logoError) {
         this.logoBitmap = null;
      }
      this.logoControl = null;
      if (this.logoBitmap && !this.logoBitmap.isNull) {
         this.logoControl = new Control(this);
         this.logoControl.bitmap = this.logoBitmap;
         this.logoControl.setScaledFixedSize(160, 120);
         this.logoControl.onPaint = function() {
            let graphics = new Graphics(this);
            graphics.drawScaledBitmap(
               new Rect(0, 0, this.width, this.height), this.bitmap);
            graphics.end();
         };
      }

      this.description = new Label(this);
      this.description.text = "Select an open color image.";
      this.description.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;

      this.preservationDescription = new Label(this);
      this.preservationDescription.text =
         "InNova Editor preserves the original and creates a new edited result.";
      this.preservationDescription.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;

      this.sourceLabel = new Label(this);
      this.sourceLabel.text = "Image:";
      this.sourceLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.sourceLabel.setFixedWidth(90);

      this.sourceCombo = new ComboBox(this);
      this.sourceCombo.setMinWidth(430);

      this.refreshButton = new PushButton(this);
      this.refreshButton.text = "Refresh";
      this.refreshButton.icon =
         this.scaledResource(":/icons/reload.png");
      this.refreshButton.onClick = function () {
         dialog.populateImages();
      };

      this.runButton = new PushButton(this);
      this.runButton.text = "Run Editor";
      this.runButton.icon =
         this.scaledResource(":/icons/power.png");
      this.runButton.onClick = function () {
         dialog.runEditor();
      };

      this.closeButton = new PushButton(this);
      this.closeButton.text = "Close";
      this.closeButton.icon =
         this.scaledResource(":/icons/close.png");
      this.closeButton.onClick = function () {
         dialog.cancel();
      };

      let imageRow = new HorizontalSizer;
      imageRow.spacing = 8;
      imageRow.add(this.sourceLabel);
      imageRow.add(this.sourceCombo, 100);
      imageRow.add(this.refreshButton);

      let buttons = new HorizontalSizer;
      buttons.spacing = 10;
      buttons.addStretch();
      buttons.add(this.runButton);
      buttons.add(this.closeButton);
      buttons.addStretch();

      let logoRow = null;
      if (this.logoControl) {
         logoRow = new HorizontalSizer;
         logoRow.addStretch();
         logoRow.add(this.logoControl);
         logoRow.addStretch();
      }

      let descriptionRow = new HorizontalSizer;
      descriptionRow.addStretch();
      descriptionRow.add(this.description);
      descriptionRow.addStretch();

      let preservationDescriptionRow = new HorizontalSizer;
      preservationDescriptionRow.addStretch();
      preservationDescriptionRow.add(this.preservationDescription);
      preservationDescriptionRow.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      if (logoRow) {
         this.sizer.add(logoRow);
         this.sizer.addSpacing(8);
      }
      this.sizer.add(descriptionRow);
      this.sizer.add(preservationDescriptionRow);
      this.sizer.add(imageRow);
      this.sizer.addSpacing(4);
      this.sizer.add(buttons);

      this.populateImages();
      this.adjustToContents();
   }

   populateImages()
   {
      let previousId = this.sourceCombo.currentItem > 0 ?
         this.sourceCombo.itemText(this.sourceCombo.currentItem) : "";
      let activeId = ImageWindow.activeWindow &&
                     !ImageWindow.activeWindow.isNull ?
                     ImageWindow.activeWindow.mainView.id : "";

      this.sourceCombo.clear();
      this.sourceCombo.addItem("<Select a color image>");
      let selectedIndex = 0;
      let windows = ImageWindow.windows;

      for (let i = 0; i < windows.length; ++i) {
         let window = windows[i];
         if (!window || window.isNull || !window.mainView ||
             window.mainView.isNull || !window.mainView.image ||
             window.mainView.image.numberOfChannels < 3)
            continue;

         this.sourceCombo.addItem(window.mainView.id);
         let itemIndex = this.sourceCombo.numberOfItems - 1;
         if (window.mainView.id === previousId ||
             (previousId.length === 0 && window.mainView.id === activeId))
            selectedIndex = itemIndex;
      }

      this.sourceCombo.currentItem = selectedIndex;
   }

   runEditor()
   {
      if (this.sourceCombo.currentItem < 1) {
         new MessageBox(
            "Select an open color image.",
            "InNova Editor",
            StdIcon_Warning,
            StdButton_Ok
         ).execute();
         return;
      }

      let sourceId = this.sourceCombo.itemText(this.sourceCombo.currentItem);
      let source = ImageWindow.windowById(sourceId);
      if (!source || source.isNull || !source.mainView ||
          source.mainView.isNull) {
         this.populateImages();
         return;
      }

      let projectType = InNovaEditorInferProjectType(sourceId);
      let outputId = MiraUniqueWindowId(sourceId + "_InNovaEditor");
      let output = InNovaEditorCloneWindow(source, outputId);

      InNovaEditorResetEditorState();
      ProjecTypevar = projectType;
      ProjecTypevarRec = projectType;

      MiraConsoleSection("🪐 InNova Editor editing: " + sourceId);

      let editorResult;
      try {
         editorResult = InNovaEditorRunProEditor(
            output.mainView, projectType);
      }
      catch (error) {
         output.forceClose();
         new MessageBox(
            "The image editor could not prepare the selected image.\n\n" +
            (error.message || error) + "\n\n" +
            "Review the Process Console for details.",
            "InNova Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }

      if (!editorResult.accepted) {
         output.forceClose();
         if (editorResult.openRequested) {
            console.noteln(
               "🪐 InNova Editor returned to the image selector.");
            this.populateImages();
            return;
         }
         if (editorResult.cancelled) {
            console.noteln("🪐 InNova Editor editing cancelled.");
            return;
         }
         new MessageBox(
            "The image editor could not prepare the selected image.\n\n" +
            "Review the Process Console for details.",
            "InNova Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Editor result created: " + outputId);
      console.noteln("✅ Process finished.");
      MiraConsoleSectionEnd();
      this.populateImages();
   }
}

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");


if (MiraRequireCompatiblePixInsight("InNova Editor") &&
    _0x5bd1131af4()) {


   InitializeInNovaProviderPaths();
   originalFilePathMLDenoisefin =
      GetInNovaDataFilePath(StarMLDenoiseModel);
   Settings.write("originalFilePathMLDenoisefin", DataType_String,
                  originalFilePathMLDenoisefin);

   let dialog = new InNovaEditorDialog;
   dialog.onShow = function () {
      MiraCenterDialog(this);
   };
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   dialog.execute();
}

#endif
